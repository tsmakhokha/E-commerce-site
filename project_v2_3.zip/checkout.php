<?php
$active='Account';
include("includes/header.php");
?>
<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="index.php">Home</a>
            
            </li>
            <li>Registration</li>
         
         </ul>
      </div>
            
   <div class="col-md-3">
        
       
       <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Brands
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-manufacturer" data-action="filter" placeholder="Filter Brands">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-manufacturer"><!-- category menu -->
         
       <?php
         
        $get_brand = "select * from brand where brand_top='yes'";
         $run_brand = mysqli_query($con, $get_brand);
         
         while($row_brand=mysqli_fetch_array($run_brand)){
             
             $brand_id = $row_brand['brand_id'];
             
             $brand_name = $row_brand['brand_name'];

             $brand_image = $row_brand['brand_image'];
             
             if(($brand_image == "")){
                 
                 
             }
             else{
                 $brand_image = "<img src='admin_area/other_images/$brand_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$brand_id' type='checkbox' class='get_brand' name='brand'>
                   <span>
                  $brand_image
                  $brand_name 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_brand = "select * from brand where brand_top='no'";
         $run_brand = mysqli_query($con, $get_brand);
         
         while($row_brand=mysqli_fetch_array($run_brand)){
             
             $brand_id = $row_brand['brand_id'];
             
             $brand_name = $row_brand['brand_name'];

             $brand_image = $row_brand['brand_image'];
             
             if(($brand_image == "")){
                 
                 
             }
             else{
                 $brand_image = "<img src='admin_area/other_images/$brand_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$brand_id' type='checkbox' class='get_brand' name='brand'>
                   <span>
                  $brand_image
                  $brand_name 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
       
       
        <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Categories
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-cat" data-action="filter" placeholder="Filter Category">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-cat"><!-- category menu -->
         
       <?php
         
        $get_cat = "select * from categories where cat_top='yes'";
         $run_cat = mysqli_query($con, $get_cat);
         
         while($row_cat=mysqli_fetch_array($run_cat)){
             
             $cat_id = $row_cat['cat_id'];
             
             $cat_title = $row_cat['cat_title'];

             $cat_image = $row_cat['cat_image'];
             
             if(($cat_image == "")){
                 
                 
             }
             else{
                 $cat_image = "<img src='admin_area/other_images/$cat_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$cat_id' type='checkbox' class='get_cat' name='cat'>
                   <span>
                  $cat_image
                  $cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_cat = "select * from categories where cat_top='no'";
         $run_cat = mysqli_query($con, $get_cat);
         
         while($row_cat=mysqli_fetch_array($run_cat)){
             
             $cat_id = $row_cat['cat_id'];
             
             $cat_title = $row_cat['cat_title'];

             $cat_image = $row_cat['cat_image'];
             
             if(($cat_image == "")){
                 
                 
             }
             else{
                 $cat_image = "<img src='admin_area/other_images/$cat_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$cat_id' type='checkbox' class='get_cat' name='cat'>
                   <span>
                  $cat_image
                  $cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
       
       
        <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title"> Product Categories
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-p_cat" data-action="filter" placeholder="Filter Products Category">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-p-cat"><!-- category menu -->
         
       <?php
         
        $get_p_cat = "select * from product_categories where p_cat_top='yes'";
         $run_p_cat = mysqli_query($con, $get_p_cat);
         
         while($row_p_cat=mysqli_fetch_array($run_p_cat)){
             
             $p_cat_id = $row_p_cat['p_cat_id'];
             
             $p_cat_title = $row_p_cat['p_cat_title'];

             $p_cat_image = $row_p_cat['p_cat_image'];
             
             if(($p_cat_image == "")){
                 
                 
             }
             else{
                 $p_cat_image = "<img src='admin_area/other_images/$p_cat_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$p_cat_id' type='checkbox' class='get_P_cat' name='p_cat'>
                  
                   <span>
                  $p_cat_image
                  $p_cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_p_cat = "select * from product_categories where p_cat_top='no'";
         $run_p_cat = mysqli_query($con, $get_p_cat);
         
         while($row_p_cat=mysqli_fetch_array($run_p_cat)){
             
             $p_cat_id = $row_p_cat['p_cat_id'];
             
             $p_cat_title = $row_p_cat['p_cat_title'];

             $p_cat_image = $row_p_cat['p_cat_image'];
             
             if(($p_cat_image == "")){
                 
                 
             }
             else{
                 $p_cat_image = "<img src='admin_area/other_images/$p_cat_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input value='$p_cat_id' type='checkbox' class='get_p_cat' name='p_cat'>
                  
                   <span>
                  $p_cat_image
                  $p_cat_title 
             
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
   </div>

       <div class="col-md-9">
<?php
       if(!isset($_SESSION['customer_email'])){
           include("customer/customer_login.php");
           
       }
       else{
           include("payment_options.php");
       }
       
       
       ?>
</div>
 </div>

</div> <!-- id=content ends here -->

<?php

include("includes/footer.php");

?>



<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>


</body>
</html>

