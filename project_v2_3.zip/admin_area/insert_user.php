<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>

<!DOCTYPE html>
<html>
<head>
  
 <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  
    <!--
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
   
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="css/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   
     -->
   
 <meta name="description" content="">
  
  <title>Add Admin</title>
  
  
  
</head>

<body>

<div class="row">

    <div class="col-lg-12">
        <ol class="breadcrumb">
        
           <li class="active">
               <p><br></p>
               <p><br></p>
              <i class="fa fa-dashboard">  Dashboard / Add Admin </i>
           
           </li>
        </ol>
    
    </div>

</div>

<div class="row">

   <div class="col-lg-12">
   
       <div class="panel panel-default">
           <div class="panel-heading">
           
              <h3 class="panel-title"> <i class="fa fa-gear fa-fw"></i> Add Admin
              </h3>
           
           </div>
           
           <div class="panel-body">
               <form class="form-horizontal" method="post" enctype="multipart/form-data">
               
                  <div class="form-group">
                      <label class="col-md-3 control-label">Admin Name</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_name" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                  <div class="form-group">
                      <label class="col-md-3 control-label">Email address</label>
                      
                      <div class="col-md-6">
                           <input type="text" name="admin_email" class="form-control" required>                 
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Password</label>
                      
                      <div class="col-md-6">
                                <input type="password" name="admin_pass" class="form-control" required>              
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Image</label>
                      
                      <div class="col-md-6">
                          <input type="file" name="admin_image" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  

                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Country</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_country" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Bio</label>
                      
                      <div class="col-md-6">
                          
                  <textarea class="form-control" name="admin_bio" cols="19" rows="6"></textarea>
                      </div>
                  
                  </div>
                   
                    <div class="form-group">
                      <label class="col-md-3 control-label">Admin Contact</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_contact" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Job</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_job" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                  
                    <div class="form-group">
                      <label class="col-md-3 control-label"></label>
                        
                      
                      <div class="col-md-6">
                         
                          <input class="btn btn-primary form-control" type="submit" name="submit" value="Add admin">
                          
                          
                      </div>
                  
                  </div>
                  
               </form>
           
           </div>
       
       
       </div>
   
   </div>
</div>


 <script src="js/tinymce.5.4.1/content/scripts/tinymce.min.js"></script>
    <script src="js/tinymce.5.4.1/content/scripts/tinymce.js"></script>
     <script>tinymce.init({selector:'textarea'});</script>
    


</body>

</html>
<!-- method to make database actually store things when we insert -->
<!-- 'submit' is for the button name, $_POST is for <for method = "post"  -->
<?php

if(isset($_POST['submit'])){
    
    
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $admin_pass = $_POST['admin_pass'];                                           
    $admin_country = $_POST['admin_country'];
    $admin_bio = $_POST['admin_about'];
    $admin_contact = $_POST['admin_contact'];
    $admin_job = $_POST['admin_job'];
   
    
    $admin_image = $_FILES['admin_image']['name'];
   
    
    $temp_name1 = $_FILES['admin_image']['tmp_name'];        /* temp name for images */
   
    
    
    /*sending image to the destination (place to be store) */
    
    move_uploaded_file($temp_name1, "admin_images/$admin_image");
       
    
    /* query and command to insert admin/user */
   
     $add_admin ="insert into admins (admin_name,admin_email,admin_pass,admin_image,admin_country,admin_about,admin_contact,admin_job) values ('$admin_name','$admin_email','$admin_pass','$admin_image','$admin_country',' $admin_bio',' $admin_contact','$admin_job')";
        
    
    
        $run_admin_add = mysqli_query($con,$add_admin);
    
    if($run_admin_add){
        
        
        echo "
        <script>alert('Admin successfully added')</script>
        ";
        echo "
        <script>window.open('index.php?view_user','_self')</script>
        ";
    }
    
}

?>

<?php } ?>