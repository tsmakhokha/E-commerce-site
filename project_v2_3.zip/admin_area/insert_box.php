<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Add Value statement
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Value Statements</h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Value Title </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="box_name" type="text" class="form-control">
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Value Description </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <textarea name="box_desc" type="text" class="form-control" rows="5"></textarea>
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="submit" value="Add" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['submit'])){
       
       $box_name = $_POST['box_name'];
       
        $box_desc = $_POST['box_desc'];
     
       
       $view_box = "select * from boxes_section";
       
       
       $run_box = mysqli_query($con, $view_box);
       
       $count = mysqli_num_rows($run_box);
       
       if($count < 3){

           
           $insert_box = "insert into boxes_section (box_name,box_desc) values ('$box_name','$box_desc')";
           
           $run_insert = mysqli_query($con, $insert_box);
           
           echo "<script>alert(' Operation successfully')</script>";
           
           echo "<script>window.open('index.php?insert_box','_self')</script>";
       }
       else
       {
           
           echo "<script>alert('You can only add 3 value statement for better display. Delete one/more value statement and Re-upload')</script>";
       }
   }

?>



<?php
}
?>