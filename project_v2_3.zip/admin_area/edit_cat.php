<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<?php
if(isset($_GET['edit_cat'])){
    $edit_cat_id = $_GET['edit_cat'];
    
    $edit_cat = "select * from categories where cat_id='$edit_cat_id'";
    
    $run_cat = mysqli_query($con,$edit_cat);
    
    $row_edit = mysqli_fetch_array($run_cat);
    
    $cat_id = $row_edit['cat_id'];
    
    $cat_name = $row_edit['cat_title'];
    
    $cat_top = $row_edit['cat_top'];
    
    $cat_image = $row_edit['cat_image'];
    
   
}
?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Edit  Category
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Edit Category</h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3"> Category Title </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="cat_title" type="text" class="form-control" value="<?php echo $cat_name;?>">
                            
                        
                        </div>
                        
                    </div>
                    
                    
                       <div class="form-group">
                        <label for="" class="control-label col-md-3">  Display First </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="cat_top" type="radio" value="yes"
                             <?php
                                        if($cat_top=='no'){
                                            
                                        }
                                        else{
                                            echo "checked='checked'";
                                        }
    
    
                                   ?>
                                   
                                   
                                   >
                            
                            
                            <label >Yes</label>
                            
                            <input name="cat_top" type="radio"  value="no"
                            <?php
                                        if($cat_top=='yes'){
                                            
                                        }
                                        else{
                                            echo "checked='checked'";
                                        }
    
    
                                   ?>
                                   
                                   
                                   >
                            
                            <label >No</label>
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">
                          
                            
                                Upload Category Image/Logo
                                
                           
                          </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                          <input class="form-control" type="file" name="cat_image">
                            <br>
                         <div>
                          <img src="other_images/<?php echo $cat_image; ?>" width="100px" height="100px" class="img-responsive">
                        </div>
                        </div>
                          
                    </div>
                   
                     
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="update" type="submit" class="form-control btn btn-primary" value="Update Category">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

    if(isset($_POST['update'])){
        $cat_title = $_POST['cat_title'];
         $cat_top = $_POST['cat_top'];
           
        if(is_uploaded_file($_FILES['cat_image']['tmp_name'])){
           
           $cat_image = $_FILES['cat_image']['name'];
       
       $temp_name = $_FILES['cat_image']['tmp_name'];
       
        move_uploaded_file($temp_name, "other_images/$cat_image");
           
           $update_cat = "update categories set cat_title='$cat_title',cat_top='$cat_top',cat_image='$cat_image' where cat_id='$cat_id'";
           
           $run_update = mysqli_query($con, $update_cat);
           
           if($run_update){
           echo "<script>alert('Category Updated')</script>";
           
           echo "<script>window.open('index.php?view_cat','_self')</script>";
           }
       }
       else{
        
           $update_cat = "update categories set cat_title='$cat_title',cat_top='$cat_top' where cat_id='$cat_id'";
           
           $run_update = mysqli_query($con, $update_cat);
           
            if($run_update){
           echo "<script>alert('Category Updated')</script>";
           
           echo "<script>window.open('index.php?view_cat','_self')</script>";
            }
       }
        
    }

?>


<?php 
}

?>