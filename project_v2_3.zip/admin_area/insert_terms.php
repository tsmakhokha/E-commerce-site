<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>

<!DOCTYPE html>
<html>
<head>
  
 <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  
    <!--
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
   
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="css/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   
     -->
   
 <meta name="description" content="">
  
  <title>Insert product</title>
  
  
  
</head>

<body>

<div class="row">

    <div class="col-lg-12">
        <ol class="breadcrumb">
        
           <li class="active">
               <p><br></p>
               <p><br></p>
              <i class="fa fa-dashboard">  Dashboard / Add Terms & Conditions</i>
           
           </li>
        </ol>
    
    </div>

</div>

<div class="row">

   <div class="col-lg-12">
   
       <div class="panel panel-default">
           <div class="panel-heading">
           
              <h3 class="panel-title"> <i class="fa fa-gear fa-fw"></i> Add Terms & Conditions
              </h3>
           
           </div>
           
           <div class="panel-body">
               <form class="form-horizontal" method="post" enctype="multipart/form-data">
               
                  <div class="form-group">
                      <label class="col-md-3 control-label">Terms Name</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="terms_name" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                   
                  <div class="form-group">
                      <label class="col-md-3 control-label">Terms Link/url</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="terms_link" class="form-control" required>
                      
                      </div>
                  
                  </div>
                  
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Terms Description</label>
                      
                      <div class="col-md-6">
                          
                  <textarea class="form-control" name="terms_desc" cols="19" rows="6"></textarea>
                      </div>
                  
                  </div>
                  
                    <div class="form-group">
                      <label class="col-md-3 control-label"></label>
                        
                      
                      <div class="col-md-6">
                         
                          <input class="btn btn-primary form-control" type="submit" name="submit" value="Add">
                          
                          
                      </div>
                  
                  </div>
                  
               </form>
           
           </div>
       
       
       </div>
   
   </div>
</div>

    
   

 <script src="js/tinymce.5.4.1/content/scripts/tinymce.min.js"></script>
    <script src="js/tinymce.5.4.1/content/scripts/tinymce.js"></script>
     <script>tinymce.init({selector:'textarea'});</script>
    


</body>

</html>
<!-- method to make database actually store things when we insert -->
<!-- 'submit' is for the button name, $_POST is for <for method = "post"  -->

 <?php
    if(isset($_POST['submit'])){
        
        $terms_name =  $_POST['terms_name'];
            $terms_link =$_POST['terms_link'];
            $terms_desc = $_POST['terms_desc'];
        
        $insert_term ="insert into terms (terms_name,terms_link,terms_desc) values ('$terms_name','$terms_link','$terms_desc')";
        
        $run_insert = mysqli_query($con, $insert_term);
        
        if($run_insert){
            
            echo "<script>alert('Term added')</script>";
            
            echo "<script>window.open('index.php?view_terms','_self')</script";
            
        }
    }
    
    ?>
    
    
    <?php } ?>
