<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>


<?php
if(isset($_GET['edit_terms'])){
    $edit_term_id = $_GET['edit_terms'];
    
    $edit_term = "select * from terms where terms_id='$edit_term_id'";
    
    $run_edit_terms = mysqli_query($con,$edit_term);
    
    $row_term = mysqli_fetch_array($run_edit_terms);
    
    $terms_id = $row_term['terms_id'];
    
    $terms_link = $row_term['terms_link'];
    
    $terms_name = $row_term['terms_name'];
    
    $terms_desc = $row_term['terms_desc'];
    
   
    
}

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Edit Terms & Conditions
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Edit Terms</h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Terms Title </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="terms_name" type="text" class="form-control" value="<?php echo $terms_name ;?>">
                            
                        
                        </div>
                        
                    </div>
                    
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Terms Link </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="terms_link" type="text" class="form-control" value="<?php echo $terms_link ;?>">
                            
                        
                        </div>
                        
                    </div>
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Terms Description </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <textarea name="terms_desc" rows="6" cols="65"><?php echo $terms_desc ;?></textarea>
                            
                        
                        </div>
                        
                    </div>
                    
                     
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="update" value="Update" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['update'])){
       $terms_name = $_POST['terms_name'];
       
       $terms_link = $_POST['terms_link'];
        $terms_desc = $_POST['terms_desc'];
       
     
       
       $update_terms = "update terms set terms_name='$terms_name',terms_link='$terms_link',terms_desc='$terms_desc' where terms_id='$terms_id'";
       
       $run_update = mysqli_query($con, $update_terms);
       
       
       if( $run_update){
            echo "<script>alert('Update successful')</script>";
           
           echo "<script>window.open('index.php?view_terms','_self')</script>";
       }
   }

?>



<?php
}
?>