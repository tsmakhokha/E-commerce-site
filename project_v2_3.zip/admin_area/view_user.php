<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<div class="row">
<div class="col-lg-12">

   <ol class="breadcrumb">
       <li class="active">
       <p><br></p>
           <p><br></p>
           <i class="fa fa-dashboard"></i> Dashboard / Users
       </li>
    </ol>
    
</div>
</div>

<div class="row">


    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
                <h3 class="panel-title"><i class="fa fa-users"> Admins</i></h3>
            </div>
            
            <!-- 1st section -->
            <div class="panel-body">
            
                <div class="table-responsive">
                
                    <table class="table table-striped table-bordered table-hover">
                    
                        <thead>
                        
                            <tr>
                            
                            <th> No </th>
                            <th> Admin Name </th>
                            <th> Admin Image </th>
                            <th> E-mail Address </th>
                            <th> Country </th>
                            <th> Admin Bio </th>
                            <th> Contact Details </th>
                            <th> Admin Job </th>
                                <th> Edit Admin </th>
                            <th> Delete Admin </th>
                            
                            </tr>
                        
                        </thead>
                        
                        <tbody>
                        
                        
                            <?php
    
                                    $i=0;
                            $get_users = "select * from admins";

                                $run_admin = mysqli_query($con, $get_users);

                                while($row_admin=mysqli_fetch_array($run_admin)){

                                    $admin_id = $row_admin['admin_id'];

                                    $admin_name = $row_admin['admin_name'];

                                    $admin_img = $row_admin['admin_image'];
                                

                                    $admin_email =$row_admin['admin_email'];

                                    $admin_country =$row_admin ['admin_country'];
                                    
                                    $admin_bio = $row_admin['admin_about'];

                                    
                                    
                                     $admin_cont = $row_admin['admin_contact'];
                                    
                                     $admin_job = $row_admin['admin_job'];

                                    $i++;
                            
                            ?>
                            
                            <tr>
                            
                                <td><?php echo $admin_id;?></td>
                            <td><?php echo $admin_name;?></td>
                            <td><img src="admin_images/<?php echo  $admin_img ;?>" width="50" height="50"></td>
                            <td> <?php echo $admin_email;?></td>
                                <td> <?php echo $admin_country;?></td>
                            
                            <td><?php echo $admin_bio;?></td>
                            <td><?php echo  $admin_cont;?></td>
                                <td><?php echo $admin_job ;?></td>
                            
                                <td>
                                
                                <a href="index.php?user_profile=<?php echo $admin_id; ?>">
                                <i class="fa fa-user"> Edit Admin</i>
                                
                                
                                </a></td>
                            
                                <td>
                                
                                <a href="index.php?delete_admin=<?php echo $admin_id; ?>">
                                <i class="fa fa-trash"> Delete</i>
                                
                                
                                </a></td>
                            
                            
                            </tr>
                            
                            <?php } ?>
                            
                        </tbody>
                    
                    </table>
                
                </div>
            </div> <!-- 1st section ends -->
            
            
        </div>
    
    </div>
</div>

<?php 
}
?>