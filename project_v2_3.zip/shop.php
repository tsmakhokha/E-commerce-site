<?php 
$active='Shop';
include_once('includes/header.php');

?>

 <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   

<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="index.php">Home</a>
            
            </li>
            <li>Shop</li>
         
         </ul>
      </div>
   <div class="col-md-3">
       
       
       <?php
       ///filters for brand should be able to carry on to the next page
                $aBrand = array();
                $aCat = array();
                $aPCat = array();
       
       if (isset($_REQUEST['brand'])&&is_array($_REQUEST['brand'])){
           
           foreach($_REQUEST['brand'] as $sKey=>$sVal){
               if((int)$sVal!=0){
                   $aBrand[(int)$sVal] = (int)$sVal;
               }
           }
       }
        ///filters for product categories should be able to carry on to the next page
       
       if (isset($_REQUEST['p_cat'])&&is_array($_REQUEST['p_cat'])){
           
           foreach($_REQUEST['p_cat'] as $sKey=>$sVal){
               if((int)$sVal!=0){
                   $aPCat[(int)$sVal] = (int)$sVal;
               }
           }
       }
       
        ///filters for categories should be able to carry on to the next page
       if (isset($_REQUEST['cat'])&&is_array($_REQUEST['cat'])){
           
           foreach($_REQUEST['cat'] as $sKey=>$sVal){
               if((int)$sVal!=0){
                   $aCat[(int)$sVal] = (int)$sVal;
               }
           }
       }
       
       ?>
       
       <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Brands
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-manufacturer" data-action="filter" placeholder="Filter Brands">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-manufacturer"><!-- category menu -->
         
       <?php
         
        $get_brand = "select * from brand where brand_top='yes'";
         $run_brand = mysqli_query($con, $get_brand);
         
         while($row_brand=mysqli_fetch_array($run_brand)){
             
             $brand_id = $row_brand['brand_id'];
             
             $brand_name = $row_brand['brand_name'];

             $brand_image = $row_brand['brand_image'];
             
             if(($brand_image == "")){
                 
                 
             }
             else{
                 $brand_image = "<img src='admin_area/other_images/$brand_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input "; 
                  
                    if(isset($aBrand[$brand_id])){
                        echo "checked='checked'";
                    }
                  
                  echo "value='$brand_id' type='checkbox' class='get_brand' name='brand'>
                  
                  <span>
                  $brand_image
                  $brand_name 
             </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_brand = "select * from brand where brand_top='no'";
         $run_brand = mysqli_query($con, $get_brand);
         
         while($row_brand=mysqli_fetch_array($run_brand)){
             
             $brand_id = $row_brand['brand_id'];
             
             $brand_name = $row_brand['brand_name'];

             $brand_image = $row_brand['brand_image'];
             
             if(($brand_image == "")){
                 
                 
             }
             else{
                 $brand_image = "<img src='admin_area/other_images/$brand_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input"; 
                  
                    if(isset($aBrand[$brand_id])){
                        echo "checked='checked'";
                    }
                  
                  echo " value='$brand_id' type='checkbox' class='get_brand' name='brand'>
                  
                   <span>
                  $brand_image
                  $brand_name 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
       
       
        <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Categories
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-cat" data-action="filter" placeholder="Filter Category">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-cat"><!-- category menu -->
         
       <?php
         
        $get_cat = "select * from categories where cat_top='yes'";
         $run_cat = mysqli_query($con, $get_cat);
         
         while($row_cat=mysqli_fetch_array($run_cat)){
             
             $cat_id = $row_cat['cat_id'];
             
             $cat_title = $row_cat['cat_title'];

             $cat_image = $row_cat['cat_image'];
             
             if(($cat_image == "")){
                 
                 
             }
             else{
                 $cat_image = "<img src='admin_area/other_images/$cat_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input ";
                  if(isset($aCat[$cat_id])){
                      echo "checked='checked'";
                  }
                  
                  echo "value='$cat_id' type='checkbox' class='get_cat' name='cat'>
                  
                   <span>
                  $cat_image
                  $cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_cat = "select * from categories where cat_top='no'";
         $run_cat = mysqli_query($con, $get_cat);
         
         while($row_cat=mysqli_fetch_array($run_cat)){
             
             $cat_id = $row_cat['cat_id'];
             
             $cat_title = $row_cat['cat_title'];

             $cat_image = $row_cat['cat_image'];
             
             if(($cat_image == "")){
                 
                 
             }
             else{
                 $cat_image = "<img src='admin_area/other_images/$cat_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input ";
                  if(isset($aCat[$cat_id])){
                      echo "checked='checked'";
                  }
                  
                  echo "value='$cat_id' type='checkbox' class='get_cat' name='cat'>
                  
                   <span>
                  $cat_image
                  $cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
       
       
        <div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title"> Product Categories
       
          <div class="pull-right">
          
              <a href="#" style="color:black";>
                 
                 <span class="nav-toggle hide-show">Close</span>
          </a>
          </div>
       </h3>
   
   </div>

           <div class="panel-collapse collapse-data">
  <div class="panel-body">
  <div class="input-group">
      
      <input type="text" class="form-control" id="dev-table-filter" data-filter="#dev-p_cat" data-action="filter" placeholder="Filter Products Category">
      <a  class="input-group-addon"><i class="fa fa-search"></i></a>
      
      </div>
      
               </div>
      
      <div class="panel-body scroll-menu">
      
      
     <ul class="nav nav-pills nav-stacked category-menu" id="dev-p_cat"><!-- category menu -->
         
       <?php
         
        $get_p_cat = "select * from product_categories where p_cat_top='yes'";
         $run_p_cat = mysqli_query($con, $get_p_cat);
         
         while($row_p_cat=mysqli_fetch_array($run_p_cat)){
             
             $p_cat_id = $row_p_cat['p_cat_id'];
             
             $p_cat_title = $row_p_cat['p_cat_title'];

             $p_cat_image = $row_p_cat['p_cat_image'];
             
             if(($p_cat_image == "")){
                 
                 
             }
             else{
                 $p_cat_image = "<img src='admin_area/other_images/$p_cat_image' width='20px'>&nbsp;";
             }

             echo "<li style='backgroud:#dddddd' class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input ";
                  if(isset($aPCat[$p_cat_id])){
                      echo "checked='checked'";
                  }
                  
                  echo " value='$p_cat_id' type='checkbox' class='get_p_cat' name='p_cat'>
                  
                   <span>
                  $p_cat_image
                  $p_cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         $get_p_cat = "select * from product_categories where p_cat_top='no'";
         $run_p_cat = mysqli_query($con, $get_p_cat);
         
         while($row_p_cat=mysqli_fetch_array($run_p_cat)){
             
             $p_cat_id = $row_p_cat['p_cat_id'];
             
             $p_cat_title = $row_p_cat['p_cat_title'];

             $p_cat_image = $row_p_cat['p_cat_image'];
             
             if(($p_cat_image == "")){
                 
                 
             }
             else{
                 $p_cat_image = "<img src='admin_area/other_images/$p_cat_image' width='20px'>&nbsp;";
             }

             echo "<li class='checkbox checkbox-primary'>
             
             <a>
             <label>
                  <input ";
                  if(isset($aPCat[$p_cat_id])){
                      echo "checked='checked'";
                  }
                  
                  echo "  value='$p_cat_id' type='checkbox' class='get_p_cat' name='p_cat'>
                  
                   <span>
                  $p_cat_image
                  $p_cat_title 
              </span>
             </label>
             
             
             </a>
             
             </li>";
         }
         
         
         ?>
         
         
         
        
         
     </ul> <!-- category menu -->
  
  </div>
               </div>
</div> <!-- sidebar menu ends -->
       
      
        
  


   
   </div>
   
   <div class="col-md-9">
   
      
       <div class='box'>
           <h1>Shop</h1>
           <p>
           I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping. I love shopping.
           </p>
       
       </div>
       
           <div id="products" class="row"><!-- row Begin -->

               <?php getProducts(); ?>
               
               </div><!-- row Finish -->
               
               <center>
                   <ul class="pagination"><!-- pagination Begin -->

                        <?php getPaginator(); ?>

                   </ul><!-- pagination Finish -->
               </center>
               
           </div><!-- col-md-9 Finish -->

           <div id="wait" style="position:absolute;top:40%;left:45%;padding: 200px 100px 100px 100px;"></div>
           
       </div><!-- container Finish -->
   </div><!-- #content Finish -->
   
   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    <script>
    
        $(document).ready(function(){

            // Hide & Show Sidebar Toggle //

            $('.nav-toggle').click(function(){
                
                $('.panel-collapse,.collapse-data').slideToggle(700,function(){

                    if($(this).css('display')=='none'){

                        $(".hide-show").html('Show');

                    }else{

                        $(".hide-show").html('Hide');

                    }

                });

            });

            // Finish Hide & Show Sidebar Toggle //

            // Search Filters | by Letter // 

            $(function(){

                $.fn.extend({

                    filterTable: function(){

                        return this.each(function(){

                            $(this).on('keyup', function(){

                                var $this = $(this),
                                search = $this.val().toLowerCase(),
                                target = $this.attr('data-filters'),
                                handle = $(target),
                                rows = handle.find('li a');

                                if(search == ''){

                                    rows.show();

                                }else{

                                    rows.each(function(){

                                        var $this = $(this);

                                        $this.text().toLowerCase().indexOf(search) === -1 ? $this.hide() : $this.show();

                                    });

                                }
                            });

                        });

                    }

                });

                $('[data-action="filter"][id="dev-table-filter"]').filterTable();

            });

            // Finish Search Filters | by Letter //

        });
    
    </script>

    <script>
    
        $(document).ready(function(){

            // getProducts Function Begin //

            function getProducts(){

                // Code For Manufacturers Begin //

                var sPath = '';
                var aInputs = $('li').find('.get_brand');
                var aKeys = Array();
                var aValues = Array();

                iKey = 0;

                $.each(aInputs, function(key, oInput){

                    if(oInput.checked){

                        aKeys[iKey] = oInput.value

                    };

                    iKey++;

                });

                if(aKeys.length>0){

                    var sPath = '';

                    for(var i = 0; i < aKeys.length; i++){

                        sPath = sPath + 'brand[]=' + aKeys[i]+'&';

                    }

                }

                // Code For Manufacturers Finish //

                // Code For Product Categories Begin //

                var aInputs = Array();
                var aInputs = $('li').find('.get_p_cat');
                var aKeys = Array();
                var aValues = Array();

                iKey = 0;

                $.each(aInputs, function(key, oInput){

                    if(oInput.checked){

                        aKeys[iKey] = oInput.value

                    };

                    iKey++;

                });

                if(aKeys.length>0){

                    var sPath = '';

                    for(var i = 0; i < aKeys.length; i++){

                        sPath = sPath + 'p_cat[]=' + aKeys[i]+'&';

                    }

                }

                // Code For Product Categories Finish //

                // Code For Categories Begin //

                var aInputs = Array();
                var aInputs = $('li').find('.get_cat');
                var aKeys = Array();
                var aValues = Array();

                iKey = 0;

                $.each(aInputs, function(key, oInput){

                    if(oInput.checked){

                        aKeys[iKey] = oInput.value

                    };

                    iKey++;

                });

                if(aKeys.length>0){

                    var sPath = '';

                    for(var i = 0; i < aKeys.length; i++){

                        sPath = sPath + 'cat[]=' + aKeys[i]+'&';

                    }

                }

                // Code For Categories Finish //

                // Loader When Loading Begin //    

                $('#wait').html('<img src="images/load.gif"');

                // Loader When Loading Finish //  

                $.ajax({

                    url:"load.php",
                    method:"POST",

                    data: sPath+'sAction=getProducts',

                    success:function(data){

                        $('#products').html('');
                        $('#products').html(data);
                        $('#wait').empty();

                    }

                });

                $.ajax({

                    url:"load.php",
                    method:"POST",

                    data: sPath+'sAction=getPaginator',

                    success:function(data){

                        $('.pagination').html('');
                        $('.pagination').html(data);

                    }

                });

            }

            // getProducts Function Finish //

            $('.get_brand').click(function(){
                getProducts();
            });

            $('.get_p_cat').click(function(){
                getProducts();
            });

            $('.get_cat').click(function(){
                getProducts();
            });

        });
    
    </script>
    
    
</body>
</html>