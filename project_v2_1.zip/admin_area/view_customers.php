<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<div class="row">
<div class="col-lg-12">

   <ol class="breadcrumb">
       <li class="active">
       <p><br></p>
           <p><br></p>
           <i class="fa fa-dashboard"></i> Dashboard / View Customers
       </li>
    </ol>
    
</div>
</div>

<div class="row">


    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
                <h3 class="panel-title"><i class="fa fa-users">View Customers</i></h3>
            </div>
            
            <!-- 1st section -->
            <div class="panel-body">
            
                <div class="table-responsive">
                
                    <table class="table table-striped table-bordered table-hover">
                    
                        <thead>
                        
                            <tr>
                            
                            <th> No </th>
                            <th> Customer Name </th>
                            <th> Customer Image </th>
                            <th> E-mail Address </th>
                            <th> Country </th>
                            <th> City </th>
                            <th> Physical/Shipping Address </th>
                            <th> Contact Details </th>
                            <th> Delete Customer </th>
                            
                            </tr>
                        
                        </thead>
                        
                        <tbody>
                        
                        
                            <?php
    
                                    $i=0;
                            $get_cust = "select * from customers";

                                $run_cust = mysqli_query($con, $get_cust);

                                while($row_cust=mysqli_fetch_array($run_cust)){

                                    $cust_id = $row_cust['customer_id'];

                                    $cust_name = $row_cust['customer_name'];

                                    $cust_img = $row_cust['customer_image'];
                                

                                    $cust_email =$row_cust['customer_email'];

                                    $cust_country =$row_cust['customer_country'];
                                    
                                    $cust_city = $row_cust['customer_city'];

                                    $cust_addr = $row_cust['customer_address'];
                                    
                                     $cust_cont = $row_cust['customer_contact'];

                                    $i++;
                            
                            ?>
                            
                            <tr>
                            
                                <td><?php echo $cust_id;?></td>
                            <td><?php echo $cust_name;?></td>
                            <td><img src="../customer/images/<?php echo $cust_img;?>" width="50" height="50"></td>
                            <td> <?php echo $cust_email;?></td>
                                <td> <?php echo $cust_country;?></td>
                            
                            <td><?php echo $cust_city;?></td>
                            <td><?php echo $cust_addr;?></td>
                                <td><?php echo$cust_cont ;?></td>
                            <td>
                                
                                <a href="index.php?delete_customer=<?php echo $cust_id; ?>">
                                <i class="fa fa-trash"> Delete</i>
                                
                                
                                </a></td>
                            
                            
                            </tr>
                            
                            <?php } ?>
                            
                        </tbody>
                    
                    </table>
                
                </div>
            </div> <!-- 1st section ends -->
            
            
        </div>
    
    </div>
</div>

<?php 
}
?>