<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<div class="row">
<div class="col-lg-12">

   <ol class="breadcrumb">
       <li class="active">
       <p><br></p>
           <p><br></p>
           <i class="fa fa-dashboard"></i> Dashboard / View Orders
       </li>
    </ol>
    
</div>
</div>

<div class="row">


    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
                <h3 class="panel-title"><i class="fa fa-shopping-cart"> Orders</i></h3>
            </div>
            
            <!-- 1st section -->
            <div class="panel-body">
            
                <div class="table-responsive">
                
                    <table class="table table-striped table-bordered table-hover">
                    
                        <thead>
                        
                            <tr>
                            
                            <th> Order No </th>
                            <th> Customer Email </th>
                            <th> Invoice No </th>
                            <th> Product Name </th>
                            <th> Quantity </th>
                            <th> Size </th>
                            <th> Order Date </th>
                            <th> Total Amount </th>
                            <th> Status </th>
                            <th> Delete Order (not advised) </th>
                            
                            </tr>
                        
                        </thead>
                        
                        <tbody>
                        
                        
                            <?php
    
                                    $i=0;
                            $get_orders = "select * from pending_orders";

                                $run_orders = mysqli_query($con, $get_orders);

                                while($row_orders=mysqli_fetch_array($run_orders)){

                                    $order_id = $row_orders['order_id'];

                                    $cust_id = $row_orders['customer_id'];

                                    $invoice_no = $row_orders['invoice_no'];
                                

                                    $pro_id =$row_orders['product_id'];

                                    $qty =$row_orders['qty'];
                                    
                                    $size = $row_orders['size'];
                                    
                                    $order_date = $row_orders['size'];

                                    $status = $row_orders['order_status'];
                                    
                                    $get_products = "select * from products where product_id='$pro_id'";
                                    
                                    $run_get_pro = mysqli_query($con, $get_products);
                                    
                                    $row_products = mysqli_fetch_array($run_get_pro);
                                    
                                    $product_title = $row_products['product_title'];
                                    
                                    
                                    $get_customer = "select * from customers where customer_id='$cust_id'";
                                    
                                    $run_customer = mysqli_query($con, $get_customer);
                                    
                                    
                                    $row_customer = mysqli_fetch_array($run_customer);
                                    
                                    
                                    $cust_email = $row_customer['customer_email'];
                                    
                                    
                                    $get_cust_orders = "select * from customer_orders where order_id='$order_id'";
                                    
                                    $run_cust_order = mysqli_query($con,$get_cust_orders);
                                    
                                    $row_cust_order = mysqli_fetch_array($run_cust_order);
                                    
                                    $order_date = $row_cust_order['order_date'];
                                    
                                    $order_due_amount = $row_cust_order['due_amount'];
                                    
                                    

                                    $i++;
                            
                            ?>
                            
                            <tr>
                            
                                <td><?php echo $order_id ;?></td>
                            <td><?php echo $cust_email ;?></td>
                            <td><?php echo $invoice_no ;?></td>
                            <td> <?php echo $product_title ;?></td>
                                <td> <?php echo  $qty ;?></td>
                            
                            <td><?php echo $size ;?></td>
                            <td><?php echo $order_date ;?></td>
                                <td><?php echo $order_due_amount ;?></td>
                            <td><?php echo $status ;?></td>
                            <td>
                                
                                <a href="index.php?delete_order=<?php echo $order_id; ?>">
                                <i class="fa fa-trash"> Delete</i>
                                
                                
                                </a></td>
                            
                            
                            </tr>
                            
                            <?php } ?>
                            
                        </tbody>
                    
                    </table>
                
                </div>
            </div> <!-- 1st section ends -->
            
            
        </div>
    
    </div>
</div>

<?php 
}
?>