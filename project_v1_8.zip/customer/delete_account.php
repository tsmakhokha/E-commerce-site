<center>

<h2>Are you sure you want to delete your account? </h2>

  <form action="" method="post">
  
    <input type="submit" name="Yes" value="Yes, delete" class="btn btn-danger">
    
    <input type="submit" name="No" value="No, just a mistake" class="btn btn-primary">

  </form>

</center>