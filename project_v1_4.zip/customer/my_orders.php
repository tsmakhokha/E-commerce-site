<center>

    <h1>My orders</h1>
    <p class="lead">Your orders in one place</p>
    <p class="text-muted"> Orders My Orders here Yippie. Orders My Orders here Yippie. Orders My Orders here Yippie. Orders My Orders here Yippie </p>

</center>

<hr>

<div class="table-responsive">

    <table class="table table-bordered table-hover">
    
       <thead>
           <tr>
           
               <th> ON: </th>
           
               <th> Due Amount: </th>
       
               <th> INvoice number: </th>
       
               <th> Qty: </th>
       
               <th> SIze: </th>
       
               <th> Order Date: </th>
       
               <th> Paid / UNpaid: </th>
       
               <th> Status: </th>
       
           </tr>
       
       </thead>
       
        <tbody>
        
            <tr>
            
                <th> #1 </th>
                
                <td> R400 </td>
            
            <td> #65442</td>
            
            <td> 4 </td>
            
            <td> Medium </td>
            
            <td> 23-07-2020 </td>
            
            <td> Unpaid </td>
            
            <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confrim order</a></td>
            
            </tr>
        
        
            <tr>
            
                <th> #1 </th>
                
                <td> R400 </td>
            
            <td> #65442</td>
            
            <td> 4 </td>
            
            <td> Medium </td>
            
            <td> 23-07-2020 </td>
            
            <td> Unpaid </td>
            
            <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confrim order</a></td>
            
            </tr>
        
            <tr>
            
                <th> #1 </th>
                
                <td> R400 </td>
            
            <td> #65442</td>
            
            <td> 4 </td>
            
            <td> Medium </td>
            
            <td> 23-07-2020 </td>
            
            <td> Unpaid </td>
            
            <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confrim order</a></td>
            
            </tr>
        
        
        </tbody>
    
    
    </table>
</div>