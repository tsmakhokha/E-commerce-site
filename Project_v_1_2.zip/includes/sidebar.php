<div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Products Category</h3>
   
   </div>

  <div class="panel-body">
  
     <ul class="nav nav-pills nav-stacked category-menu"><!-- category menu -->
         <li><a href="#">Jackets</a></li>
     <li><a href="#">Accessories</a></li>
     <li><a href="#">Shoes</a></li>
     <li><a href="#">Coats</a></li>
     <li><a href="#">T-shirts</a></li>
     </ul> <!-- category menu -->
  
  </div>
</div> <!-- sidebar menu ends -->

<div class="panel panel-default sidebar-menu"> <!-- sidebar menu-->
   <div class="panel-heading">
      <h3 class="panel-title">Category</h3>
   
   </div>

  <div class="panel-body">
  
     <ul class="nav nav-pills nav-stacked category-menu"><!-- category menu -->
         <li><a href="#">Men</a></li>
     <li><a href="#">Woman</a></li>
     <li><a href="#">Kids</a></li>
     <li><a href="#">Other</a></li>
     
     </ul> <!-- category menu -->
  
  </div>
</div> <!-- sidebar menu ends -->