<div id="footer"> <!--footer -->

   <div class="container">
   
       <div class="row">
       
         <div class="col-sm-6 col-md-3">
             
             <h4>Pages</h4>
             
         <ul> <!--list -->
           <li><a href="../cart.php">Shopping cart</a></li>
           <li><a href="../contact.php">Contact us</a></li>
           <li><a href="../shop.php">Shop</a></li>
           <li><a href="my_account.php">My account</a></li>

         </ul> <!-- list ends -->
         <hr>
         <h4>Customer section</h4>
         <ul>
            <li><a href="../checkout.php">Login</a></li>
            <li><a href="../customer_register.php">Register</a></li>
         
         </ul>
         
         <hr class="hidden-md hidden-lg hidden-sm">
         
         </div>
         
         <div class="col-sm-6 col-md-3">
         
             <h4>Top products categories</h4>
             
             <ul>
               <li><a href="#">Jackets</a></li>
               <li><a href="#">Accessories</a></li>
               <li><a href="#">Coats</a></li>
               <li><a href="#">Shoes</a></li>
               <li><a href="#">T-Shirts</a></li>

             </ul>
         
          <hr class="hidden-md hidden-lg">

         </div>
         
         <div class="col-sm-6 col-md-3">
         
            <h4>Find Us:</h4>
            
                <p>
                
                <strong>
                TWOTE STORE worldwide pty <br>
                Sandton City <br>
                South Africa <br>
                Tel: 011 234 5678<br>
                Email: tsmakhokha@gmail.com
                </strong>
                
                
                </p>
                
                <a href="../contact.php">Get in touch</a>
         
         <hr class="hidden-md hidden-lg">
         
         </div>
         
         <div class="col-sm-6 col-md-3">
            <h4>Sign up for newsletter</h4>
            <p class="text-muted">
              Get latest news and promotions straight to your phone. Sign up for newsletter 
            </p>
            
            <form action="get" method="post"> <!-- input form-->
                <div class="input-group">
                 
                   <input type="text" class="form-control" name="email">
                       <span class="input-group-btn">
                       
                            <input type="submit" value="subscribe" class="btn btn-default">
                       
                       </span>
                   
                </div>
            
            </form> <!-- form ends -->
            
            <hr>
            
            <h4>Follow us on Socials</h4>
            
            <p class="social">
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-google-plus"></a>
            <a href="#" class="fa fa-pinterest"></a>
            
            </p>
            
         </div>
         
       </div>
   
   </div>

</div> <!-- footer ends -->

<div id="copyright"> <!-- copyright -->

   <div class="container">
   
      <div class="col-md-6">
      
      <p class="pull-left">&copy; 2020  TwoteStore</p>
      
      </div>
      
      <div class="col-md-6">
      
      <p class="pull-right">Developed by: <a href="https://www.linkedin.com/in/tshivhidzo-makhokha-54ab6111b/">Tshivhidzo</a></p>
      
      </div>
 
   </div>

</div>