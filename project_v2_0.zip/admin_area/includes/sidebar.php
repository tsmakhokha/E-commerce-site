<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>


<nav class="navbar navbar-inverse navbar-fixed-top">
 <!-- top right nav bar menu -->
<div class="navbar-header">
    
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-exl-collapse">
    
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    
    </button>
    
    <a href="index.php?dashboard" class="navbar-brand">Admin Panel</a>
    
    </div>
    
    <ul class="nav navbar-right top-nav">
    
    <li class="dropdown">
        
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-user"> <?php echo $admin_name; ?></i> <b class="caret"></b>
        </a>
        
        <ul class="dropdown-menu">
        <li>
            <a href="index.php?user_profile=<?php echo $admin_id; ?>">
            <i class="fa fa-fw fa-user"></i>Profile
            
            </a>
            </li>
            
            
            <li>
            <a href="index.php?view_products>">
            <i class="fa fa-fw fa-envelope"></i>View Products
            <span class="badge"><?php echo $count_products; ?></span>
            </a>
            </li>
            
            <li>
            <a href="index.php?view_customers">
            <i class="fa fa-fw fa-user"></i>View Customers
            <span class="badge"><?php echo $count_customers; ?></span>
            </a>
            </li>
        
        <li>
            <a href="index.php?view_cat">
            <i class="fa fa-fw fa-user"></i>View Products category
                <span class="badge"><?php echo $count_p_categories; ?></span>
            
            </a>
            </li>
            <li class="divider"></li>
            <li>
            <a href="logout.php">
            <i class="fa fa-fw fa-power-off"></i>Log out
                
            </a>
            </li>
            
        </ul>
        
        </li>
    
    </ul>
    
    <!-- Top left nav/menu -->
    <div class="collapse navbar-collapse navbar-ext-collapse">
    <ul class="nav navbar-nav side-nav">
        <li>
        
            
            <a href="index.php?dashboard">
            <i class="fa fa-fw fa-dashboard"></i>  Dashboard
                
            
            </a>
            
        
        </li>
        
         <li>
        
            
            <a href="#" data-toggle="collapse" data-target="#products">
            <i class="fa fa-fw fa-tag"></i> Products
            <i class="fa fa-fw fa-caret-down"></i>
                
            
            </a>
            
             <ul id="products" class="collapse">
             <li>
                 <a href="index.php?insert_products">Add products</a>
                 </li><li>
                 <a href="index.php?view_products">View products</a>
                 </li>
             </ul>
        
        </li>
        
        <li>
        
            
            <a href="#" data-toggle="collapse" data-target="#p_cat">
            <i class="fa fa-fw fa-edit"></i> Product Categories
            <i class="fa fa-fw fa-caret-down"></i>
                
            
            </a>
            
             <ul id="p_cat" class="collapse">
             <li>
                 <a href="index.php?insert_p_cat">Create product category</a>
                 </li><li>
                 <a href="index.php?view_p_cat">View products Categories</a>
                 </li>
             </ul>
        
        </li>
        
        <li>
        
            
            <a href="#" data-toggle="collapse" data-target="#cat">
            <i class="fa fa-fw fa-edit"></i> Categories
            <i class="fa fa-fw fa-caret-down"></i>
                
            
            </a>
            
             <ul id="cat" class="collapse">
             <li>
                 <a href="index.php?insert_cat">Create Category</a>
                 </li><li>
                 <a href="index.php?view_cat">View categories</a>
                 </li>
             </ul>
        
        </li>
        
        <li>
        
            
            <a href="#" data-toggle="collapse" data-target="#slides">
            <i class="fa fa-fw fa-gear"></i> Slides
            <i class="fa fa-fw fa-caret-down"></i>
                
            
            </a>
            
             <ul id="slides" class="collapse">
             <li>
                 <a href="index.php?insert_slide">Add Slide</a>
                 </li><li>
                 <a href="index.php?view_slide">View Slides</a>
                 </li>
             </ul>
        
        </li>
        
        <li><a href="index.php?view_customers"><i class="fa fa-fw fa-users"></i> View Customers</a></li>
         <li><a href="index.php?view_orders"><i class="fa fa-fw fa-shopping-cart"></i> View Orders</a></li>
         <li><a href="index.php?view_payments"><i class="fa fa-fw fa-money"></i> View Payments</a></li>
        
        
        <li>
        
            
            <a href="#" data-toggle="collapse" data-target="#users">
            <i class="fa fa-fw fa-gear"></i> Users
            <i class="fa fa-fw fa-caret-down"></i>
                
            
            </a>
            
             <ul id="users" class="collapse">
             <li>
                 <a href="index.php?insert_user">Add User</a>
                 </li>
                 
                 <li>
                 <a href="index.php?view_user">View Users</a>
                 </li>
                 
                 <li>
                 <a href="index.php?user_profile=<?php echo $admin_id; ?>">Edit Users</a>
                 </li>
             </ul>
        
        </li>
        
         <li><a href="logout.php"><i class="fa fa-fw fa-power-off"></i> Log out</a></li> 
        
        
        </ul>
    </div>

</nav>

<?php
}
?>