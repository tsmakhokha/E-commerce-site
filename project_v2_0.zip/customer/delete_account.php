<center>

<h2>Are you sure you want to delete your account? </h2>

  <form action="" method="post">
  
    <input type="submit" name="Yes" value="Yes, delete" class="btn btn-danger">
    
    <input type="submit" name="No" value="No, just a mistake" class="btn btn-primary">

  </form>

</center>

<?php
$c_email = $_SESSION['customer_email'];

if(isset($_POST['Yes'])){
    
    $delete_customer = "delete from customers where customer_email='$c_email'";
    
    $run_del = mysqli_query($con, $delete_customer);
    
    if($run_del){
        session_destroy();
        
        echo "<script> alert('Account deleted')</script>";
        
        echo "<script> window.open('../index.php','_self')</script>";
    }
}

if (isset($_POST['No'])){
    
    echo "<script> alert('Pheew, dodged that bullet. Glad you staying')</script>";
    echo "<script>window.open ('my_account.php?my_orders','_self')</script>";
}

?>