<center>

    <h1>Make Payment offline</h1>
    
    <p class="text-muted"> If you encounter any problems, do <a href="../contact.php">Contact us</a> </p>

</center>


<div class="table-responsive">

    <table class="table table-bordered table-hover table-striped">
    
       <thead>
           <tr>
              <th> Store Deposit Details: </th>
              <th> EFT Details: </th>
              <th> Paypal Details: </th>
               
           </tr>
       
       </thead>
       
        <tbody>
        
            <td>
             Store Name: Pickn'pay | Account No: 1234567890 | Account Holder: Fallen Company | Reference No: Your order number. 
            </td>
        <td>
           Bank Name: TymeBank | Account no: 1234567890 | Branch code: 44332 | Account Type: Cheque | Reference: Your order number.
        </td>
           
        <td>
        
         E-mail: tsmakhokha@gmail.com
        </td>
        </tbody>
    
    
    </table>
</div>