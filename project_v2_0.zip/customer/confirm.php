<?php
session_start();

if(!isset($_SESSION['customer_email'])){
    
    echo "<script> window.open ('../checkout.php','_self')</script>";
}
else{

include("includes/db.php");
include("functions/functions.php");
    
    if(isset($_GET['order_id'])){
        
        $order_id = $_GET['order_id'];
        
    }
    
?>

<!DOCTYPE html>
<html  >

<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   
   
 <meta name="description" content="">
  
  <title>Home</title>
  
  
  
</head>
<body>
<div id="top"> <!--Top begining -->

<div class="container"> <!-- constainer start-->

<div class="col-md-6 offer">

<a href="#" class="btn btn-success btn-sm"><?php
    if(!isset($_SESSION['customer_email'])){
        
        echo "Welcome: Guest";
    }
    else
    {
        echo "Welcome: ".$_SESSION['customer_email']."";
    }
    
    ?>
</a>
<a href="../checkout.php"><?php items();?> Items in cart | Total Price: R <?php total_price(); ?></a>


</div> 

<div class="col-md-6"> 
<ul class="menu"><!-- top menu start-->

<li>
<a href="../customer_register.php">Register</a>
</li>
<li>
<a href="my_account.php?my_orders">my account</a>

</li>
<li>
<a href="../cart.php">Cart</a>

</li>
<li>
<a href="../checkout.php"> <?php
    if(!isset($_SESSION['customer_email'])){
        
        echo "<a href='checkout.php'> Login </a>";
    }
    else
    {
        echo "<a href='logout.php'> Log out </a>";
    }
    
    ?></a>
</li>

</ul><!-- end of  top menu-->
</div>
</div> <!-- container end-->

</div> <!--End of top-->

<div id="navbar" class="navbar navbar-default"> <!-- navbar begins-->
<div class="container">

<div class="navbar-header">

<a href="../index.php" class="navbar-brand home">

<img src="images/small_logo.png" alt="store logo" class="hidden-xs">
<img src="images/small_logo.png" alt="store logo" class="visible-xs">

</a>

<button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
<span class="sr-only">Toggle Naviation</span>
<i class="fa fa-align-justify"></i>
</button>

<button class="navbar-toggle" data-toggle="collapse" data-target="#search">
<span class="sr-only">Toggle Search</span>
<i class="fa fa-search"></i>
</button>


</div>

<div class="navbar-collapse collapse" id="navigation">

<div class="padding-nav">

<ul class="nav navbar-nav left"> <!-- navbar menu list -->

<li>
<a href="../index.php">Home</a>
</li>

<li>
<a href="../shop.php">Shop</a>
</li>

<li class="active">
<a href="my_account.php?my_orders">My account</a>
</li>

<li>
<a href="../cart.php">Cart</a>
</li>

<li>
<a href="../contact.php">Contact us</a>
</li>

</ul> <!-- End of menu items -->  

</div>
 <a href="../cart.php" class="btn navbar-btn btn-primary right">
 <i class="fa fa-shopping-cart"></i>
 <span><?php items();?> items in cart</span>
 
 </a>
<div class="navbar-collapse collapse right">

<button class="btn btn-primary navbar-btn" type="button" data-toggle="collapse" data-target="#search">

<span class="sr-only">Toggle Search</span>
<i class="fa fa-search"></i>
</button> 


</div> 

<div class="collapse clearfix" id="search">

<form method="get" action="results.php" class="navbar-form">
<div class="input-group">

<input type="text" class="form-control" placeholder="Search" name="user_query" required>
<span class="input-group-btn">
<button type="submit" name="search" value="Search" class="btn btn-primary"> <!-- buton for search and display results on results page-->

<i class="fa fa-search"></i>

</button> 
</span>
</div>

</form>

</div>
</div>

 
</div>


</div><!-- navbar ends-->

<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="../index.php">Home</a>
            
            </li>
            <li>My account</li>
         
         </ul>
      </div>
   <div class="col-md-3">
        
        <?php
        
        include("includes/sidebar.php");
        
        ?>
   
   </div>
   

<div class="col-md-9">
    <div class="box">
        <h1 align="center">Confirm your payment</h1>
        
        <form action="confirm.php?update_id=<?php echo $order_id; ?>" method="post" enctype="multipart/form-data">
        
             <div class="form-group">
                 <label>Invoice no:</label>
                 
                 <input type="text" class="form-control" name="invoice_no" required>
             
             </div>
        
        <div class="form-group">
                 <label>Amount paid:</label>
                 
                 <input type="text" class="form-control" name="amount_sent" required>
             
             </div>
             
             <div class="form-group">
                 <label>Select payment method:</label>
                 
                <select name="payment_method" class="form-control">
                
                    <option> Selct option </option>
                <option> Cash deposit </option>
                <option> EFT </option>
                <option> Credit card </option>
                <option> PayPal </option>
                
                </select>
             
             </div>
        
        <div class="form-group">
                 <label> Reference no: </label>
                 
                 <input type="text" class="form-control" name="ref_no" required>
             
             </div>
             
        <div class="form-group">
                 <label>Cell number</label>
                 
                 <input type="text" class="form-control" name="cell_num" required>
             
             </div>
             <div class="form-group">
                 <label>Date of deposit:</label>
                 
                 <input type="text" class="form-control" name="date" required>
             
             </div>
             
             <div class="text-center">
                 <button class="btn btn-primary btn-lg" name="confirm_payment"><i class="fa fa-user-md">  Confirm payment</i></button>
             
             </div>
        
        
        
        </form>
    <?php
        if (isset($_POST['confirm_payment'])){
            $update_id = $_GET['update_id'];
            
            $invoice_no = $_POST['invoice_no'];
            
            $amount = $_POST['amount_sent'];
            
            
            $payment_method = $_POST['payment_method'];
            
            
            $ref_no = $_POST['ref_no'];
            
            $cell_num = $_POST['cell_num'];
            
            $payment_date = $_POST['date'];
            
            
            $complete = "complete";
            
            $insert_payment = "insert into payments (invoice_no,amount,payment_method,ref_no,cell_num,payment_date) values (' $invoice_no','$amount','$payment_method','$ref_no','$cell_num','$payment_date')";
            
            $run_payment = mysqli_query($con, $insert_payment);
            
            $update_cust_order = "update customer_orders set order_status='$complete' where order_id='$update_id'";
            
            $run_cust_order = mysqli_query ($con, $update_cust_order);
            
            $update_pending_order = "update pending_orders set order_status='$complete' where order_id='$update_id'";
            
            $run_pending_order = mysqli_query ($con, $update_pending_order);
            
            if($run_pending_order){
                
                echo "<script> alert ('Thank you for ordering, order to be processed ASAP')</script>";
                
                echo "<script> window.open('my_account.php?my_orders','_self')</script>";
            }
        }
        
        ?>
    </div>

</div>



</div>

</div> <!-- id=content ends here -->

<?php

include("includes/footer.php");

?>



<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>


</body>
</html>

<?php
}
?>