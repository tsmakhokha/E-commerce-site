<h2 align="center">Change password</h2>

<form action="" method="post">
     
     <div class="form-group">
     
     <label>
           Old password:
     </label>
         <input type="text" name="old_pass" class="form-control" required>
         
         
     </div>
     
          <div class="form-group">
     
     <label>
           New Password:
     </label>
         <input type="text" name="new_pass" class="form-control" required>
         
         
     </div>
     
          <div class="form-group">
     
     <label>
           Confirm new password:
     </label>
         <input type="text" name="confirm_pass" class="form-control" required>
         
         
     </div>


     <div class="text-center">
          <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-user-md">  Update Password</i></button>
     
     </div>




</form>

<?php
if(isset($_POST['submit'])){
    
    
    $c_email = $_SESSION['customer_email'];
    
    $c_old_pass = $_POST['old_pass'];
    
    $new_pass = $_POST['new_pass'];
    
    $confirm_pass = $_POST['confirm_pass'];
    
    $sel_old_pass = "select * from customers where customer_pass='$c_old_pass'";
    
    $run_old_pass = mysqli_query($con, $sel_old_pass);
    
    $check_old_pass = mysqli_fetch_array($run_old_pass);
    
    if($check_old_pass==0){
        
        echo "<script> alert ('Old password is incorrect :-(, try again ')</script>";
        
        exit();
    }
    if($new_pass!=$confirm_pass){
        echo "<script> alert ('New Password and Confirm password do not match :-( . Try again  ')</script>";
        
        exit();
    }
    
    $update_pass = "update customers set customer_pass='$new_pass' where customer_email='$c_email'";
    
    $run_update = mysqli_query($con, $update_pass);
    
    if($run_update){
        echo "<script> alert ('New Password updated ')</script>";
            
            echo "<script> window.open('my_account.php?my_orders','_self')</script>";
    }
}


?>