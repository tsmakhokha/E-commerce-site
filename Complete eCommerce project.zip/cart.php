<?php
$active='Cart';
include("includes/header.php");
?>
<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="index.php">Home</a>
            
            </li>
            <li>Shopping cart</li>
         
         </ul>
      </div>
      
      <div id="cart" class="col-md-9"> <!-- cart begins -->
      
      
        <div class="box">
        
             <form action="cart.php" method="post" enctype="multipart/form-data">
             
             <h1>Shopping cart</h1>
                 
                 <?php
                 $ip_add = getRealIpUser();
                 
                 $connect_cart = "select * from cart where ip_add='$ip_add'";
                 
                 $run_cart = mysqli_query($con,$connect_cart);
                 $count = mysqli_num_rows($run_cart);
                 ?>
             
             <p class="text-muted">You have <?php  echo $count; ?> items in your cart</p>
             
             <div class="table-responsive">
             
                    <table class="table">
                    
                       <thead>
                       
                             <tr>
                             
                             <th colspan="2">Product</th>
                            <th>Quntity</th>
                            <th>Product price</th>
                                 <th>Sale price</th>
                            <th>Size</th>
                            <th colspan="1">Clear cart</th>
                            <th colspan="2">Subtotal</th>
                                 
                             
                             </tr>
                       
                       </thead>
                       
                       <tbody>
                           
                           <?php
                           $total = 0;
                           
                           while($row_cart=mysqli_fetch_array($run_cart)){
                               $pro_id = $row_cart['p_id'];
                            $pro_size = $row_cart['size'];
                            $pro_qty = $row_cart['qty'];
                           
                               $sale_price = $row_cart['p_price'];
                               
                               $get_products = "select * from products where product_id='$pro_id'";
                           
                               $run_products = mysqli_query($con, $get_products);
                               
                               while($row_products=mysqli_fetch_array($run_products)){
                                   
                                   $product_title = $row_products['product_title'];
                                   $product_url = $row_products['product_url'];
                                   $product_img1 = $row_products['product_img1'];
                                   $only_price = $row_products['product_price'];  //price for 1 item in cart
                               
                                   $sub_total = $sale_price * $pro_qty;
                                   
                                   $_SESSION['pro_qty'] = $pro_qty;
                                   
                                   $total += $sub_total;
                               
                           ?>
                           
                           <tr>
                           
                                <td>
                                
                                
                                    <img class="img-responsive" src="admin_area/product_images/<?php echo $product_img1;?>" alt="product">
                                
                                </td>
                           <td>
                           
                               <a href="<?php echo $product_url; ?>"><?php echo $product_title;?></a>
                           </td>
                           
                           <td>
                             <input type="text" name="quantity" data-product_id="<?php echo $pro_id; ?>"
                                    value="<?php echo $_SESSION['pro_qty']; ?>" class="quantity form-control">
                           </td>
                           
                           <td>
                              R <?php echo $only_price;?>
                           
                           </td>
                            <td>
                               
                             R <?php echo  $sale_price;
                                   ?>
                           </td>
                              
                           <td>
                               
                              <?php echo $pro_size;?>
                           
                           </td>
                               
                               
                           
                           <td>
                               <input type="checkbox" name="remove[]" value="<?php echo $pro_id;?>">
                           </td>
                           
                           <td>
                            R <?php echo $sub_total;?>
                           </td>
                           </tr>
                       <?php
                               }
                           }
                           ?>
                       </tbody>
                     
                    <tfoot>
                    
                       <tr>
                           <th colspan="5">Total</th>
                           <td colspan="5"><strong>R <?php echo $total;?></strong></td>
                       
                       </tr>
                    
                    </tfoot>
                    
                    </table>    
              <!-- coupon code section -->
                 <div class="form-inline pull-right">
                 
                     <div class="form-group">
                        <label>Coupon Code</label>
                         <input type="text" name="code" class="form-control">
                         <input type="submit" class="btn btn-primary" value="Redeem Coupon" name="apply_coupon"> 
                         
                     </div>
                 </div>
             <!-- END coupon code section -->
             </div>
                 
             <div class="box-footer">
             
                 <div class="pull-left">
                 
                      <a href="shop.php" class="btn btn-default">
                      <i class="fa fa-chevron-left">  Back to shopping</i>
                      
                      </a>
                 
                 
                 </div>
                 <div class="pull-right">
                 
                      <button type="submit" name="update" value="Update Cart" class="btn btn-default">
                      <i class="fa fa-refresh">  Update cart</i>
                      
                      </button>
                 
                 <a href="checkout.php" class="btn btn-primary">
                 
                 Proceed to checkout <i class="fa fa-chevron-right"></i>
                 
                 </a>
                 
                 </div>
             
             </div>
             
             </form>
        
        </div>
          
          <?php
            if(isset($_POST['apply_coupon'])){
                $code = $_POST['code'];
                if($code ==""){
                    
                }
                else{
                    $get_coupon = "select * from coupons where coupon_code='$code'";
                    $run_coupon = mysqli_query($con, $get_coupon);
                    
                    $check_coupon = mysqli_num_rows($run_coupon);
                    
                    if($check_coupon == "1"){
                        $row_coupon = mysqli_fetch_array($run_coupon);
                        
                        $coupon_pro_id = $row_coupon['product_id'];
                        
                        $coupon_price = $row_coupon['coupon_price'];
                        
                        $coupon_limit = $row_coupon['coupon_limit'];
                        
                        $coupon_used = $row_coupon['coupon_used'];
                        
                        if($coupon_limit == $coupon_used){
                            echo "<script>alert('Coupon already used')</script>";
                        }
                        else{
                            $get_cart = "select * from cart where p_id='$coupon_pro_id' AND ip_add='$ip_add'";
                            $run_cart = mysqli_query($con,$get_cart);
                            $check_cart = mysqli_num_rows($run_cart);
                            
                            if($check_cart =="1"){
                              $add_used = "update coupons set coupon_used=coupon_used+1 where coupon_code='$code'";
                                $run_add = mysqli_query($con, $add_used);
                                
                                $update_cart = "update cart set p_price='$coupon_price' where p_id='$coupon_pro_id' AND ip_add='$ip_add'";
                                
                                $run_cart_update = mysqli_query($con, $update_cart);
                                
                                echo "<script>alert('coupon applied')</script>";
                                
                                echo "<script>window.open('cart.php','_self')</script>";


                            }
                            else{
                                echo "<script>alert('Coupon code not for this product')</script>";
                            }
                        }
                    }
                    else{
                        echo "
                        <script>alert('Coupon not valid')</script>
                        ";
                    }
                }
            }
          ?>
        
        <?php
          
          function update_cart(){
              global $con;
              
              if (isset($_POST['update'])){
                  
                  foreach($_POST['remove'] as $remove_id){
                      
                      $delete_product = "delete from cart where p_id='$remove_id'";
                      
                      $run_delete = mysqli_query($con, $delete_product);
                          
                      if($run_delete){
                          echo"
                          <script>window.open('cart.php', '_self')</script>
                          
                          ";
                      }
                  }
              }
          }
          
          echo $up_cart = update_cart();
          
          
          ;
          
          ?>
          
  <div id="row same-height-row"> <!--Suggested heading prod -->
     <div class="col-md-12">
       
           <h3 class="text-center">You may also like</h3>
        
       
     
     </div>
     <?php 
     
     $get_products = "select * from products order by rand() LIMIT 0,3";
     
     $run_products = mysqli_query($con, $get_products);
     
     while ($row_products=mysqli_fetch_array($run_products)){
         $pro_id=$row_products['product_id'];
        
        $pro_title=$row_products['product_title'];
         $pro_url=$row_products['product_url'];
        
        $pro_price=$row_products['product_price'];
        
        $pro_sale_price =$row_products['product_sale'];
                
        $pro_img1=$row_products['product_img1'];
        
        $pro_label=$row_products['product_label'];
        
        $brand_id=$row_products['brand_id'];
        
        /*$get_brand = "select * from brand where brand_id='$brand_id'";
        
        $run_brand = mysqli_query($db, $get_brand );
        
        
        $row_brands = mysqli_fetch_array($run_brand);
        
        $br_name = $row_brands['brand_name']; */
        
        if($pro_label == "sale"){
            
            $product_price = "Was <del> R $pro_price </del> &nbsp;Now";
            
             $product_sale_price = "R $pro_sale_price";
        }     
        else{
            $product_price = "R $pro_price ";
            
            $product_sale_price = "";
        }
        
        if($pro_label ==""){
            
        }
        else{
            $product_label = "
            <a href='#' class='label $pro_label' >
                        <div class='theLabel'>$pro_label</div>
                        
                        <div class='labelBackground'></div>
                        
            
            </a>
            ";
        }
        
        echo "
        <div class='col-md-4 col sm-6 center-responsive'>
           <div class='product'>
               <a href='$pro_url'>
            
            <img class='img-responsive' width='50%' src='admin_area/product_images/$pro_img1'>
            
            </a>
            
            <div class='text'>
            
            
               <h3>
            
            <a href='$pro_url'>
            
            $pro_title
            
            </a>
            
            
            </h3>

<p class='price'> $product_price $product_sale_price </p>



</div>

 $product_label
           
           </div>
        
        </div>
        ";
        
        
             
    
     
     
     
     }
     
     ?>
     
 </div>
 


      </div> <!-- cart ends -->
      
      <div class="col-md-3">
          <div id="order-summary" class="box">
          
              <div class="box-header">
                  <h3>Order Summary</h3>
              
              </div>
              
              <p class="text-muted">Shipping and otheer cost calculated at the end</p>
              
              <div class="table-responsive">
              
                  <table class="table">
                  
                      <tbody>
                          <tr>
                               <td>Order sub-Total</td>
                               <td>R <?php echo $total;?></td>
                          
                          
                          </tr>
                          
                          <tr>
                             <td>Shipping</td>
                             <td>RO</td>
                          </tr>
                          
                          <tr>
                             <td>TAx</td>
                             <td>RO</td>
                          </tr>
                                                <tr class="total">
                             <td>Total</td>
                             <td>R <?php echo $total;?></td>
                          </tr>

                      
                      </tbody>
                  
                  </table>
              
              </div>
          
          </div>
      
      </div>

  </div>
  
  

</div> <!-- id=content ends here -->

<?php

include("includes/footer.php");

?>



<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>


<script>
    $(document).ready(function(data){
        $(document).on('keyup','.quantity',function(){
            
           var id = $ (this).data("product_id");
            var quantity = $(this).val();
            
            if(quantity !=''){
                $.ajax({
                   
                    url:"change.php",
                    method: "POST",
                    data:{id:id, quantity:quantity},
                    
                    success:function(){
                        $("body").load("cart_body.php");
                    }
                });
            }
        });
    });
</script>

</body>
</html>