<?php
$active='Account';
include("includes/header.php");
?>
<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="index.php">Home</a>
            
            </li>
            <li>Login</li>
         
         </ul>
      </div>
            
   

       <div class="col-md-12" >
           <div class="" style="margin:auto; max-width: 500px;">
<?php
       if(!isset($_SESSION['customer_email'])){
           include("customer/customer_login.php");
           
       }
       else{
           include("payment_options.php");
       }
       
       
       ?>
               
               </div>
</div>
 </div>

</div> <!-- id=content ends here -->

<?php

include("includes/footer.php");

?>



<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>


</body>
</html>

