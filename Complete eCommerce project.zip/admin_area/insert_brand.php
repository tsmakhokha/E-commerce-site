<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Add Brands
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Add Brand </h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Brand Name </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="brand_name" type="text" class="form-control">
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label for="" class="control-label col-md-3">  Display First </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="brand_top" type="radio" value="yes">
                            <label >Yes</label>
                            
                            <input name="brand_top" type="radio"  value="no">
                            <label >No</label>
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">
                          
                            
                                Upload Brand Image/Logo
                                
                           
                          </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                          <input class="form-control" type="file" name="brand_image">
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="submit" value="Upload" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['submit'])){
       $brand_name = $_POST['brand_name'];
       
        $brand_top = $_POST['brand_top'];
       
       $brand_image = $_FILES['brand_image']['name'];
       
       $temp_name = $_FILES['brand_image']['tmp_name'];
       
        move_uploaded_file($temp_name, "other_images/$brand_image");
           
           $insert_brand = "insert into brand (brand_name,brand_top,brand_image) values ('$brand_name','$brand_top','$brand_image')";
           
           $run_insert = mysqli_query($con, $insert_brand);
           
           echo "<script>alert('Operation was successfully')</script>";
           
           echo "<script>window.open('index.php?insert_brand','_self')</script>";
       
       
   }

?>



<?php
}
?>