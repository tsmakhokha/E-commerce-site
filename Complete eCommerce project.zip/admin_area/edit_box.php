<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>


<?php
if(isset($_GET['edit_box'])){
    $edit_box_id = $_GET['edit_box'];
    
    $edit_box = "select * from boxes_section where box_id='$edit_box_id'";
    
    $run_slide = mysqli_query($con,$edit_box);
    
    $row_box = mysqli_fetch_array($run_slide);
    
    $box_id = $row_box['box_id'];
    
    $box_name = $row_box['box_name'];
    
    $box_desc = $row_box['box_desc'];
    
   
    
}

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Edit Value Box
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Value Stateemnt Box</h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Value Title </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="box_name" type="text" class="form-control" value="<?php echo $box_name ;?>">
                            
                        
                        </div>
                        
                    </div>
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Value Description </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <textarea name="box_desc" rows="6" cols="65"><?php echo $box_desc ;?></textarea>
                            
                        
                        </div>
                        
                    </div>
                    
                     
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="update" value="Update" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['update'])){
       $box_title = $_POST['box_name'];
       
        $box_desc = $_POST['box_desc'];
       
     
       
       $update_box = "update boxes_section set box_name='$box_title',box_desc='$box_desc' where box_id='$box_id'";
       
       $run_update = mysqli_query($con, $update_box);
       
       
       if( $run_update){
            echo "<script>alert('Update successful')</script>";
           
           echo "<script>window.open('index.php?view_boxes','_self')</script>";
       }
   }

?>



<?php
}
?>