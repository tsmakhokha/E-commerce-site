<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<?php
    
    if(isset($_GET['edit_brand'])){
        
        $edit_brand= $_GET['edit_brand'];
        $get_brand = "select * from brand where brand_id='$edit_brand'";
        
        $run_brand = mysqli_query($con, $get_brand);
    
        $row_brand = mysqli_fetch_array($run_brand);
        
        
        $br_id = $row_brand['brand_id'];
        
        $br_name = $row_brand['brand_name'];
        
        $br_top = $row_brand['brand_top'];
        
        $br_image = $row_brand['brand_image'];
    
    }


?>


<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Edit Brands
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Edit Brand </h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Brand Name </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="brand_name" type="text" class="form-control" value="<?php echo $br_name; ?>">
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label for="" class="control-label col-md-3">  Display First </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="brand_top" type="radio" value="yes"
                                   
                                   <?php
                                        if($br_top=='no'){
                                            
                                        }
                                        else{
                                            echo "checked='checked'";
                                        }
    
    
                                   ?>
                                   
                                   
                                   >
                            <label >Yes</label>
                            
                            <input name="brand_top" type="radio"  value="no"
                                   <?php
                                        if($br_top=='yes'){
                                            
                                        }
                                        else{
                                            echo "checked='checked'";
                                        }
    
    
                                   ?>
                                   
                                   
                                   >
                            <label >No</label>
                            
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">
                          
                            
                                Upload Brand Image/Logo
                                
                           
                          </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                          <input class="form-control" type="file" name="brand_image">
                            <br>
                            <img width="100" height="100" src="other_images/<?php echo $br_image ;?>" alt="<?php echo $br_image ;?>">
                        
                        </div>
                        
                    </div>
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="update" value="Update" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['update'])){
       $brand_name = $_POST['brand_name'];
       
        $brand_top = $_POST['brand_top'];
       
       if(is_uploaded_file($_FILES['brand_image']['tmp_name'])){
           
           $brand_image = $_FILES['brand_image']['name'];
       
       $temp_name = $_FILES['brand_image']['tmp_name'];
       
        move_uploaded_file($temp_name, "other_images/$brand_image");
           
           $update_brand = "update brand set brand_name='$brand_name',brand_top='$brand_top',brand_image='$brand_image' where brand_id='$br_id'";
           
           $run_insert = mysqli_query($con, $update_brand);
           
           if($run_insert){
           echo "<script>alert('Brand Updated')</script>";
           
           echo "<script>window.open('index.php?view_brands','_self')</script>";
           }
       }
       else{
        
           $update_brand = "update brand set brand_name='$brand_name',brand_top='$brand_top' where brand_id='$br_id'";
           
           $run_insert = mysqli_query($con, $update_brand);
           
            if($run_insert){
           echo "<script>alert('Brand Updated')</script>";
           
           echo "<script>window.open('index.php?view_brands','_self')</script>";
            }
       }
      
   }

?>



<?php
}
?>