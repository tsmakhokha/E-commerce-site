<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / View Coupons
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Coupons/Promo codes </h3>
            </div>
            
            <div class="panel-body">
            
                <div class="table-responsive">
                <table class="table table-hover table striped table-bordered">
                
                    <thead>
                    
                        <tr>
                        
                            <th>Coupon ID</th>
                             <th>Product ID</th>
                        <th>Coupon Name</th>
                        <th>Coupon Price</th>
                            <th>Coupon Code</th>
                            <th>Coupon Limit</th>
                            <th>Coupon Used</th>
                        <th>Edit Coupon</th>
                        <th>Delete Coupon</th>
                        
                        
                        </tr>
                    
                    </thead>
                
                    <tbody>
                        
                        <?php
                        $i=0;
    $get_cat = "select * from coupons";
    $run_cat = mysqli_query($con,$get_cat);
    
    while($row_cat = mysqli_fetch_array($run_cat)){
        $coupon_id = $row_cat['coupon_id'];
        $pro_id = $row_cat['product_id'];
   $coupon_name = $row_cat['coupon_name'];
        
        $coupon_price = $row_cat['coupon_price'];
        
        $coupon_code = $row_cat['coupon_code'];
        $coupon_limit = $row_cat['coupon_limit'];
        $coupon_used = $row_cat['coupon_used'];
   
   
        $i++;
  
    
                        ?>
                                
                        <tr>
                        <td><?php echo $coupon_id ;?></td>
                        <td><?php echo $pro_id  ;?></td>
                        <td><?php echo $coupon_name ;?></td>
                            <td><?php echo $coupon_price ;?></td>
                            <td><?php echo $coupon_code ;?></td>
                            <td><?php echo $coupon_limit ;?></td>
                            <td><?php echo $coupon_used ;?></td>
                        
                            <td>
                                <a href="index.php?edit_coupon=<?php echo $coupon_id; ?>"><i class="fa fa-pencil"></i> Edit</a>
                            </td>
                            
                            <td>
                                <a href="index.php?delete_coupon=<?php echo $coupon_id; ?>"><i class="fa fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                        
                            <?php  } ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    
    </div>

</div>


<?php 
}

?>