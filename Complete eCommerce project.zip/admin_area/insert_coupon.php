<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / Coupon-Promo Code
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Add Coupon-Promo Code </h3>
            </div>
            
            <div class="panel-body">
            
                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Coupon Name </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="coupon_name" type="text" class="form-control">
                            
                        
                        </div>
                        
                    </div>
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Coupon Price </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="coupon_price" type="text" class="form-control">
                            
                        
                        </div>
                        
                    </div>
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Coupon Code </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="coupon_code" type="text" class="form-control">
                            
                        
                        </div>
                        
                    </div>
                    
                    <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  Coupon Limit </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input name="coupon_limit" type="number" class="form-control" value="1">
                            
                        
                        </div>
                        
                    </div>
                    
                     <div class="form-group">
                        <label class="col-md-3 control-label">  Select Product </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <select name="product_id" class="form-control" required>
                            <option selected disabled >Select the product to add Promo/Coupon Code to </option>
                            <?php
                                $get_p = "select * from products";
                                $run_p = mysqli_query($con, $get_p);
    
    
    while($row_p = mysqli_fetch_array($run_p)){
        $p_id = $row_p['product_id'];
        $p_title = $row_p['product_title'];
        
        echo "<option value='$p_id'>$p_title</option>";
    }
                                ?>
                            
                            </select>
                        
                        </div>
                        
                    </div>
                      
                    
                      
                    
                      <div class="form-group">
                        <label form="form-control" class="control-label col-md-3">  </label>
                        
                        
                        <div class="col-md-6">
                        
                        
                            <input type="submit" name="submit" value="Add Coupon" class="btn btn-primary form-control">
                            
                        
                        </div>
                        
                    </div>
                
                </form>
            
            </div>
        </div>
    
    </div>

</div>

<?php

   if(isset($_POST['submit'])){
       
       $coupon_name = $_POST['coupon_name'];
       
       $coupon_price = $_POST['coupon_price'];
       
       $coupon_code = $_POST['coupon_code'];
       
       $coupon_limit = $_POST['coupon_limit'];
       
       $pro_id = $_POST['product_id'];
       
       $get_coupon = "select * from coupons where product_id='$pro_id' or coupon_code='$coupon_code'";
       $run_coupon = mysqli_query($con, $get_coupon);
       $check_coupons = mysqli_num_rows($run_coupon);
       
       if($check_coupons == 1){
           
           echo "<script>alert('Coupon already exits for the product')</script>";
           
       }
       else{
           
       
           
           $insert_coupon = "insert into coupons (coupon_name,coupon_price,coupon_code,coupon_limit,product_id) values ('$coupon_name','$coupon_price','$coupon_code','$coupon_limit',$pro_id)";
           
           $run_insert = mysqli_query($con, $insert_coupon);
           
           echo "<script>alert('Operation was successfully')</script>";
           
           echo "<script>window.open('index.php?insert_coupon','_self')</script>";
       }
       
   }

?>



<?php
}
?>