<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<?php 
  if(isset($_GET['edit_coupon'])){
      $edit_id = $_GET['edit_coupon'];
      
      $get_p = "select * from coupons where coupon_id='$edit_id'";
      
      $run_edit = mysqli_query($con, $get_p);
      
      $row_edit = mysqli_fetch_array($run_edit);
      
      $p_id = $row_edit['product_id'];
      
      $p_title = $row_edit['product_title'];
      
       $coupon_id = $row_edit['coupon_id'];
      
      $coupon_name = $row_edit['coupon_name'];
      
      $coupon_price = $row_edit['coupon_price'];
      
      $coupon_code = $row_edit['coupon_code'];
      
      $coupon_limit = $row_edit['coupon_limit'];
      
      $get_prod = "select * from products where product_id='$p_id'";
      
      $run_prod = mysqli_query($con, $get_prod);
      $row_prod = mysqli_fetch_array($run_prod);
      
      $prod_id = $row_prod['product_id'];
      $prod_title = $row_prod['product_title'];
     
     
  }
    
?>
<!DOCTYPE html>
<html>
<head>
  
 <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  
    <!--
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
   
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="css/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   
     -->
   
 <meta name="description" content="">
  
  <title>Dashboard</title>
  
  
  
</head>

<body>

<div class="row">

    <div class="col-lg-12">
        <ol class="breadcrumb">
        
           <li class="active">
               <p><br></p>
               <p><br></p>
              <i class="fa fa-dashboard">  Dashboard / Edit Coupon</i>
           
           </li>
        </ol>
    
    </div>

</div>

<div class="row">

   <div class="col-lg-12">
   
       <div class="panel panel-default">
           <div class="panel-heading">
           
              <h3 class="panel-title"> <i class="fa fa-gear fa-fw"></i> Edit Coupon
              </h3>
           
           </div>
           
           <div class="panel-body">
               <form class="form-horizontal" method="post" enctype="multipart/form-data">
               
                  <div class="form-group">
                      <label class="col-md-3 control-label">Coupon Name</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="coupon_name" class="form-control" required value="<?php echo $coupon_name; ?>">
                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Coupon Price</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="coupon_price" class="form-control" required value="<?php echo $coupon_price; ?>">
                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Coupon Code</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="coupon_code" class="form-control" required value="<?php echo $coupon_code; ?>">
                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Coupon Limit</label>
                      
                      <div class="col-md-6">
                          <input type="number" name="coupon_limit" class="form-control" required value="<?php echo $coupon_limit; ?>">
                      
                      </div>
                  
                  </div>
                   
                 
                   
                  
                  <div class="form-group">
                      <label class="col-md-3 control-label">Select product</label>
                      
                      <div class="col-md-6">
                          <select name="product_id" class="form-control">
                              <option value="<?php echo $prod_id; ?>"> <?php echo $prod_title; ?> </option>
                               <!-- connecting to database and calling product categories table -->
                              <?php
                              
                                $get_p = "select * from products";
                                 $run_p = mysqli_query($con,$get_p);
                                 
                                 while ($row_p=mysqli_fetch_array($run_p)){
                                    $p_id = $row_p['product_id'];
                                    $p_title = $row_p['product_title'];
                                    
                                    echo "
                                    <option value ='$p_id'> $p_title </option>
                                    
                                    ";
                                    
                                 
                                 }
                              
                              ?>
                          
                          </select>                      
                      </div>
                  
                  </div>
                   
                    <div class="form-group">
                      <label class="col-md-3 control-label"></label>
                        
                      
                      <div class="col-md-6">
                         
                          <input class="btn btn-primary form-control" type="submit" name="update" value="Update Coupon">
                          
                          
                      </div>
                  
                  </div>
                  
               </form>
           
           </div>
       
       
       </div>
   
   </div>
</div>


 <script src="js/tinymce.5.4.1/content/scripts/tinymce.min.js"></script>
    <script src="js/tinymce.5.4.1/content/scripts/tinymce.js"></script>
     <script>tinymce.init({selector:'textarea'});</script>
    


</body>

</html>
<!-- method to make database actually store things when we insert -->
<!-- 'submit' is for the button name, $_POST is for <for method = "post"  -->
<?php

if(isset($_POST['update'])){ ///incase you updating everything--including pictures
    
    
    $product_id = $_POST['product_id'];
      
      $coupon_name = $_POST['coupon_name'];
      
      $coupon_price = $_POST['coupon_price'];
      
      $coupon_code = $_POST['coupon_code'];
      
      $coupon_limit = $_POST['coupon_limit'];
  
    
    /* query and command to update product */
  
    $update_coupon = "update coupons set product_id='$product_id',coupon_name='$coupon_name',coupon_price='$coupon_price',coupon_code='$coupon_code',coupon_limit='$coupon_limit' where coupon_id='$coupon_id'";
    
    $run_update = mysqli_query($con, $update_coupon);
    
    if ($run_update){
        echo "<script>alert('Coupon successfully updated')</script>";
    
        echo "<script>window.open('index.php?view_coupons','_self')</script>";
    }
    
}
    

?>

<?php } ?>