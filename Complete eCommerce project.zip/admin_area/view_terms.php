<?php


if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    

?>

<div class="row">


    <div class="col-lg-12">
    
        <ol class="breadcrumb">
        
            <li>
                <p><br></p>
                <p><br></p>
            <i class="fa fa-dashboard"></i> Dashboard / View Terms & Conditions
            </li>
        
        </ol>
    
    </div>
</div>

<div class="row">

    <div class="col-lg-12">
    
        <div class="panel panel-default">
        
        
            <div class="panel-heading">
            
            <h3 class="panel-title"><i class="fa fa-book fa-fw"></i> Terms and Conditions </h3>
            </div>
            
            <div class="panel-body">
          
                <?php
                
    $get_terms = "select * from terms";
    $run_terms = mysqli_query($con, $get_terms);
    
    while ($row_terms=mysqli_fetch_array($run_terms)){
       
        $terms_id = $row_terms['terms_id'];
        $terms_name = $row_terms['terms_name'];
        $terms_desc = $row_terms['terms_desc'];
        
    
                ?>
                
                <div class="col-lg-4 col-md-4">
                
                    <div class="panel panel-primary">
                    
                        <div class="panel-heading">
                        
                            <h3 class="panel-title" align="center"> <?php echo $terms_name; ?></h3>
                        
                        </div>
                    
                        <div class="panel-body">
                        
                           <textarea rows="6" cols="35"><?php echo $terms_desc; ?></textarea>
                        
                        </div>
                        
                        <div class="panel-footer">
                        
                        
                            <center>
                            
                                <a href="index.php?delete_terms=<?php echo $terms_id ;?>" class="pull-right"><i class="fa fa-trash"></i> Delete
                                </a>
                                
                                
                                <a href="index.php?edit_terms=<?php echo $terms_id ;?>" class="pull-left"><i class="fa fa-pencil"></i> Edit
                                </a>
                                
                                <div class="clearfix"></div>
                            
                            </center>
                        
                        </div>
                    </div>
                
                </div>
          <?php 
    }
                ?>
            </div>
        </div>
    
    </div>

</div>


<?php 
}

?>
