<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<?php 
  if(isset($_GET['user_profile'])){
      $edit_admin = $_GET['user_profile'];
      
      $get_admin = "select * from admins where admin_id='$edit_admin'";
      
      $run_edit = mysqli_query($con, $get_admin);
      
      $row_edit = mysqli_fetch_array($run_edit);
      
     $admin_id = $row_edit['admin_id'];
      $admin_name = $row_edit['admin_name'];
    $admin_email = $row_edit['admin_email'];
    $admin_pass = $row_edit['admin_pass']; 
      $admin_image = $row_edit['admin_image'];
    $admin_country = $row_edit['admin_country'];
    $admin_bio = $row_edit['admin_about'];
    $admin_contact = $row_edit['admin_contact'];
    $admin_job = $row_edit['admin_job'];
     
  }

    
?>

<div class="row">

    <div class="col-lg-12">
        <ol class="breadcrumb">
        
           <li class="active">
               <p><br></p>
               <p><br></p>
              <i class="fa fa-dashboard">  Dashboard / Edit Admin</i>
           
           </li>
        </ol>
    
    </div>

</div>


<div class="row">

   <div class="col-lg-12">
   
       <div class="panel panel-default">
           <div class="panel-heading">
           
              <h3 class="panel-title"> <i class="fa fa-pencil fa-fw"></i> Edit Admin
              </h3>
           
           </div>
           
           <div class="panel-body">
               <form class="form-horizontal" method="post" enctype="multipart/form-data">
               
                  <div class="form-group">
                      <label class="col-md-3 control-label">Admin Name</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_name" class="form-control" value="<?php echo $admin_name;?>">
                      
                      </div>
                  
                  </div>
                  
                  <div class="form-group">
                      <label class="col-md-3 control-label">Email address</label>
                      
                      <div class="col-md-6">
                           <input type="text" name="admin_email" class="form-control" value="<?php echo $admin_email;?>">                 
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Password</label>
                      
                      <div class="col-md-6">
                                <input type="text" name="admin_pass" class="form-control" value="<?php echo $admin_pass?>">              
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Image</label>
                      
                      <div class="col-md-6">
                          <input type="file" name="admin_image" class="form-control" required>
                      
                          <img src="admin_images/<?php echo $admin_image ;?>" width="100" height="100">
                      </div>
                  
                  </div>
                  

                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Country</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_country" class="form-control" value="<?php echo $admin_country;?>">
                      
                      </div>
                  
                  </div>
                  
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Bio</label>
                      
                      <div class="col-md-6">
                          
                  <textarea class="form-control" name="admin_about" cols="19" rows="6"><?php echo $admin_about?></textarea>
                      </div>
                  
                  </div>
                   
                    <div class="form-group">
                      <label class="col-md-3 control-label">Admin Contact</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_contact" class="form-control"  value="<?php echo $admin_contact; ?>">
                      
                      </div>
                  
                  </div>
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Admin Job</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="admin_job" class="form-control" value="<?php echo $admin_job; ?>">
                      
                      </div>
                  
                  </div>
                  
                  
                    <div class="form-group">
                      <label class="col-md-3 control-label"></label>
                        
                      
                      <div class="col-md-6">
                         
                          <input class="btn btn-primary form-control" type="submit" name="update" value="Update">
                          
                          
                      </div>
                  
                  </div>
                  
               </form>
           
           </div>
       
       
       </div>
   
   </div>
</div>


 <script src="js/tinymce.5.4.1/content/scripts/tinymce.min.js"></script>
    <script src="js/tinymce.5.4.1/content/scripts/tinymce.js"></script>
     <script>tinymce.init({selector:'textarea'});</script>
    



<!-- method to make database actually store things when we insert -->
<!-- 'submit' is for the button name, $_POST is for <for method = "post"  -->
<?php

if(isset($_POST['update'])){
    
    
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $admin_pass = $_POST['admin_pass'];                                           
    $admin_country = $_POST['admin_country'];
    $admin_about = $_POST['admin_about'];
    $admin_contact = $_POST['admin_contact'];
    $admin_job = $_POST['admin_job'];
   
    
    $admin_image = $_FILES['admin_image']['name'];
   
    
    $temp_name1 = $_FILES['admin_image']['tmp_name'];        /* temp name for images */
   
     
    
    /*sending image to the destination (place to be store) */
    
    move_uploaded_file($temp_name1, "admin_images/$admin_image");
       
    /* query and command to update product */
  
   
    $update_admin = "update admins set admin_name='$admin_name',admin_email='$admin_email',admin_pass='$admin_pass',admin_image='$admin_image',admin_country='$admin_country',admin_about='$admin_about',admin_contact='$admin_contact',admin_job='$admin_job' where admin_id='$admin_id'";
    
    $run_update = mysqli_query($con, $update_admin);
    
    if ($run_update){
        echo "<script>alert('Admin successfully updated')</script>";
    
        echo "<script>window.open('index.php?view_user','_self')</script>";
        
        
    }
}

?>

<?php } ?>