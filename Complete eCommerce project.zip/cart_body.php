<?php

session_start();

$active='Cart';

include("includes/db.php");
include("functions/functions.php");

?>


<body>
<div id="top"> <!--Top begining -->

<div class="container"> <!-- constainer start-->

<div class="col-md-6 offer">

<a href="#" class="btn btn-success btn-sm">
    <?php
    if(!isset($_SESSION['customer_email'])){
        
        echo "Welcome: Guest";
    }
    else
    {
        echo "Welcome: ".$_SESSION['customer_email']."";
    }
    
    ?>
    </a>
<a href="checkout.php"><?php items();?> Items in cart | Total Price: R <?php total_price(); ?></a>


</div> 

<div class="col-md-6"> 
<ul class="menu"><!-- top menu start-->

<li>
<?php
    
    if(!isset($_SESSION['customer_email'])){
        
        echo "<a href='customer_register.php'>Register</a>";
    }
    else{
     echo "<a href='customer/my_account.php?edit_account'>Edit account</a>";   
    }
    
    ?>
</li>
<li>
<?php
    
    if(!isset($_SESSION['customer_email'])){
        
        echo "<a href='checkout.php'>My account</a>";
    }
    else{
     echo "<a href='customer/my_account.php?my_orders'>My account</a>";   
    }
    
    ?>
</li>
<li>
<a href="cart.php">Cart</a>

</li>
<li>
<a href="checkout.php">
    <?php
    if(!isset($_SESSION['customer_email'])){
        
        echo "<a href='checkout.php'> Login </a>";
    }
    else
    {
        echo "<a href='logout.php'> Log out </a>";
    }
    
    ?>

    </a>
</li>

</ul><!-- end of  top menu-->
</div>
</div> <!-- container end-->

</div> <!--End of top-->

<div id="navbar" class="navbar navbar-default"> <!-- navbar begins-->
<div class="container">

<div class="navbar-header">

<a href="index.php" class="navbar-brand home">


<img  class="img-responsive"  src="images/small_logo.png" alt="store logo" class="visible-xs">

</a>

<button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
<span class="sr-only">Toggle Naviation</span>
<i class="fa fa-align-justify"></i>
</button>

<button class="navbar-toggle" data-toggle="collapse" data-target="#search">
<span class="sr-only">Toggle Search</span>
<i class="fa fa-search"></i>
</button>


</div>

<div class="navbar-collapse collapse" id="navigation">

<div class="padding-nav">

<ul class="nav navbar-nav left"> <!-- navbar menu list -->

<li class="<?php if($active=='Home') echo"active";?>">
<a href="index.php">Home</a>
</li>

<li class="<?php if($active=='Shop') echo"active";?>">
<a href="shop.php">Shop</a>
</li>

<li class="<?php if($active=='Account') echo"active";?>">
<?php
    
    if(!isset($_SESSION['customer_email'])){
        
        echo "<a href='checkout.php'>My account</a>";
    }
    else{
     echo "<a href='customer/my_account.php?my_orders'>My account</a>";   
    }
    
    ?>
</li>

<li class="<?php if($active=='Cart') echo"active";?>">
<a href="cart.php">Cart</a>
</li>

<li class="<?php if($active=='Contact') echo"active";?>">
<a href="contact.php">Contact Us</a>
</li>

</ul> <!-- End of menu items -->  

</div>
 <a href="cart.php" class="btn navbar-btn btn-primary right">
 <i class="fa fa-shopping-cart"></i>
 <span> <?php items();?> items in cart</span>
 
 </a>
<div class="navbar-collapse collapse right">

<button class="btn btn-primary navbar-btn" type="button" data-toggle="collapse" data-target="#search">

<span class="sr-only">Toggle Search</span>
<i class="fa fa-search"></i>
</button> 


</div> 

<div class="collapse clearfix" id="search">

<form method="get" action="results.php" class="navbar-form">
<div class="input-group">

<input type="text" class="form-control" placeholder="Search" name="user_query" required>
<span class="input-group-btn">
<button type="submit" name="search" value="Search" class="btn btn-primary"> <!-- buton for search and display results on results page-->

<i class="fa fa-search"></i>

</button> 
</span>
</div>

</form>

</div>
</div>

 
</div>


</div><!-- navbar ends-->

<div id="content"> <!-- content begins -->

   <div class="container">
      <div class="col-md-12" >
      
         <ul class="breadcrumb">
            <li>
            <a href="index.php">Home</a>
            
            </li>
            <li>Shopping cart</li>
         
         </ul>
      </div>
      
      <div id="cart" class="col-md-9"> <!-- cart begins -->
      
      
        <div class="box">
        
             <form action="cart.php" method="post" enctype="multipart/form-data">
             
             <h1>Shopping cart</h1>
                 
                 <?php
                 $ip_add = getRealIpUser();
                 
                 $connect_cart = "select * from cart where ip_add='$ip_add'";
                 
                 $run_cart = mysqli_query($con,$connect_cart);
                 $count = mysqli_num_rows($run_cart);
                 ?>
             
             <p class="text-muted">You have <?php  echo $count; ?> items in your cart</p>
             
             <div class="table-responsive">
             
                    <table class="table">
                    
                       <thead>
                       
                             <tr>
                             
                             <th colspan="2">Product</th>
                            <th>Quntity</th>
                            <th>Product price</th>
                                 <th>Sale price</th>
                            <th>Size</th>
                            <th colspan="1">Clear cart</th>
                            <th colspan="2">Subtotal</th>
                                 
                             
                             </tr>
                       
                       </thead>
                       
                       <tbody>
                           
                           <?php
                           $total = 0;
                           
                           while($row_cart=mysqli_fetch_array($run_cart)){
                               $pro_id = $row_cart['p_id'];
                            $pro_size = $row_cart['size'];
                            $pro_qty = $row_cart['qty'];
                           
                               $sale_price = $row_cart['p_price'];
                               
                               $get_products = "select * from products where product_id='$pro_id'";
                           
                               $run_products = mysqli_query($con, $get_products);
                               
                               while($row_products=mysqli_fetch_array($run_products)){
                                   
                                   $product_title = $row_products['product_title'];
                                    $product_url = $row_products['product_url'];
                                   $product_img1 = $row_products['product_img1'];
                                   $only_price = $row_products['product_price'];  //price for 1 item in cart
                               
                                   $sub_total = $sale_price * $pro_qty;
                                   
                                   $_SESSION['pro_qty'] = $pro_qty;
                                   
                                   $total += $sub_total;
                               
                           ?>
                           
                           <tr>
                           
                                <td>
                                
                                
                                    <img class="img-responsive" src="admin_area/product_images/<?php echo $product_img1;?>" alt="product">
                                
                                </td>
                           <td>
                           
                               <a href="<?php echo $product_url; ?>"><?php echo $product_title;?></a>
                           </td>
                           
                           <td>
                             <input type="text" name="quantity" data-product_id="<?php echo $pro_id; ?>"
                                    value="<?php echo $_SESSION['pro_qty']; ?>" class="quantity form-control"
                                    
                                    >
                           </td>
                           
                           <td>
                              R <?php echo $only_price;?>
                           
                           </td>
                            <td>
                               
                             R <?php echo  $sale_price;
                                   ?>
                           </td>
                              
                           <td>
                               
                              <?php echo $pro_size;?>
                           
                           </td>
                               
                               
                           
                           <td>
                               <input type="checkbox" name="remove[]" value="<?php echo $pro_id;?>">
                           </td>
                           
                           <td>
                            R <?php echo $sub_total;?>
                           </td>
                           </tr>
                       <?php
                               }
                           }
                           ?>
                       </tbody>
                     
                    <tfoot>
                    
                       <tr>
                           <th colspan="5">Total</th>
                           <td colspan="5"><strong>R <?php echo $total;?></strong></td>
                       
                       </tr>
                    
                    </tfoot>
                    
                    </table>    
             
             </div>
             
             <div class="box-footer">
             
                 <div class="pull-left">
                 
                      <a href="shop.php" class="btn btn-default">
                      <i class="fa fa-chevron-left">  Back to shopping</i>
                      
                      </a>
                 
                 
                 </div>
                 <div class="pull-right">
                 
                      <button type="submit" name="update" value="Update Cart" class="btn btn-default">
                      <i class="fa fa-refresh">  Update cart</i>
                      
                      </button>
                 
                 <a href="checkout.php" class="btn btn-primary">
                 
                 Proceed to checkout <i class="fa fa-chevron-right"></i>
                 
                 </a>
                 
                 </div>
             
             </div>
             
             </form>
        
        </div>
        
        <?php
          
          function update_cart(){
              global $con;
              
              if (isset($_POST['update'])){
                  
                  foreach($_POST['remove'] as $remove_id){
                      
                      $delete_product = "delete from cart where p_id='$remove_id'";
                      
                      $run_delete = mysqli_query($con, $delete_product);
                          
                      if($run_delete){
                          echo"
                          <script>window.open('cart.php', '_self')</script>
                          
                          ";
                      }
                  }
              }
          }
          
          echo $up_cart = update_cart();
          
          
          ;
          
          ?>
          
  <div id="row same-height-row"> <!--Suggested heading prod -->
     <div class="col-md-12">
       
           <h3 class="text-center">You may also like</h3>
        
       
     
     </div>
     <?php 
     
     $get_products = "select * from products order by rand() LIMIT 0,3";
     
     $run_products = mysqli_query($con, $get_products);
     
     while ($row_products=mysqli_fetch_array($run_products)){
         $pro_id=$row_products['product_id'];
        
        $pro_title=$row_products['product_title'];
         
         $pro_url=$row_products['product_url'];
        
        $pro_price=$row_products['product_price'];
        
        $pro_sale_price =$row_products['product_sale'];
                
        $pro_img1=$row_products['product_img1'];
        
        $pro_label=$row_products['product_label'];
        
        $brand_id=$row_products['brand_id'];
        
        /*$get_brand = "select * from brand where brand_id='$brand_id'";
        
        $run_brand = mysqli_query($db, $get_brand );
        
        
        $row_brands = mysqli_fetch_array($run_brand);
        
        $br_name = $row_brands['brand_name']; */
        
        if($pro_label == "sale"){
            
            $product_price = "Was <del> R $pro_price </del> &nbsp;Now";
            
             $product_sale_price = "R $pro_sale_price";
        }     
        else{
            $product_price = "R $pro_price ";
            
            $product_sale_price = "";
        }
        
        if($pro_label ==""){
            
        }
        else{
            $product_label = "
            <a href='#' class='label $pro_label' >
                        <div class='theLabel'>$pro_label</div>
                        
                        <div class='labelBackground'></div>
                        
            
            </a>
            ";
        }
        
        echo "
        <div class='col-md-4 col sm-6 center-responsive'>
           <div class='product'>
               <a href='$pro_url'>
            
            <img class='img-responsive' width='50%' src='admin_area/product_images/$pro_img1'>
            
            </a>
            
            <div class='text'>
            
            
               <h3>
            
            <a href='$pro_url'>
            
            $pro_title
            
            </a>
            
            
            </h3>

<p class='price'> $product_price $product_sale_price </p>



</div>

 $product_label
           
           </div>
        
        </div>
        ";
        
        
             
    
     
     
     
     }
     
     ?>
     
 </div>
 


      </div> <!-- cart ends -->
      
      <div class="col-md-3">
          <div id="order-summary" class="box">
          
              <div class="box-header">
                  <h3>Order Summary</h3>
              
              </div>
              
              <p class="text-muted">Shipping and otheer cost calculated at the end</p>
              
              <div class="table-responsive">
              
                  <table class="table">
                  
                      <tbody>
                          <tr>
                               <td>Order sub-Total</td>
                               <td>R <?php echo $total;?></td>
                          
                          
                          </tr>
                          
                          <tr>
                             <td>Shipping</td>
                             <td>RO</td>
                          </tr>
                          
                          <tr>
                             <td>TAx</td>
                             <td>RO</td>
                          </tr>
                                                <tr class="total">
                             <td>Total</td>
                             <td>R <?php echo $total;?></td>
                          </tr>

                      
                      </tbody>
                  
                  </table>
              
              </div>
          
          </div>
      
      </div>

  </div>
  
  

</div> <!-- id=content ends here -->

<?php

include("includes/footer.php");

?>



<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>


<script>
    $(document).ready(function(data){
        $(document).on('keyup','.quantity',function(){
            
           var id = $ (this).data("product_id");
            var quantity = $(this).val();
            
            if(quantity !=''){
                $.ajax({
                   
                    url:"change.php",
                    method: "POST",
                    data:{id:id, quantity:quantity},
                    
                    success:function(){
                        $("body").load("cart_body.php");
                    }
                });
            }
        });
    });
</script>

</body>