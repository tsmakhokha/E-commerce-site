<?php
   

if(!isset($_SESSION['admin_email'])){
    echo "<script>window.open('login.php','_self')</script>";
}
else{
    
?>
<?php 
  if(isset($_GET['edit_product'])){
      $edit_id = $_GET['edit_product'];
      
      $get_p = "select * from products where product_id='$edit_id'";
      
      $run_edit = mysqli_query($con, $get_p);
      
      $row_edit = mysqli_fetch_array($run_edit);
      
      $p_id = $row_edit['product_id'];
      
      $p_title = $row_edit['product_title'];
      
       $p_cat = $row_edit['p_cat_id'];
      
      $cat = $row_edit['cat_id'];
      
      $brand_id = $row_edit['brand_id'];
      
      $p_image1 = $row_edit['product_img1'];
      
      $p_image2 = $row_edit['product_img2'];
      
      $p_image3 = $row_edit['product_img3'];
      
      $p_price = $row_edit['product_price'];
      
      $p_keywords = $row_edit['product_keywords'];
      
      $p_desc = $row_edit['product_desc'];
     
  }
    
    $get_brand = "select * from brand where brand_id='$brand_id'";
     $run_brand = mysqli_query ($con, $get_brand);
    
    $row_brand = mysqli_fetch_array($run_brand);
    
    $brand_id = $row_brand['brand_id']; 
    $brand_name = $row_brand['brand_name'];
    
    
    $get_p_cat = "select * from product_categories where p_cat_id='$p_cat'";
    
    $run_p_cat = mysqli_query ($con, $get_p_cat);
    
    $row_p_cat = mysqli_fetch_array($run_p_cat);
    
    $p_cat_title = $row_p_cat['p_cat_title'];
    
    
    
    $get_cat = "select * from categories where cat_id='$cat'";
    
    $run_cat = mysqli_query ($con, $get_cat);
    
    $row_cat = mysqli_fetch_array($run_cat);
    
    $cat_title = $row_cat['cat_title'];
    


    
?>
<!DOCTYPE html>
<html>
<head>
  
 <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  
    <!--
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
   
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="css/bootstrap-337.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
   
     -->
   
 <meta name="description" content="">
  
  <title>Insert product</title>
  
  
  
</head>

<body>

<div class="row">

    <div class="col-lg-12">
        <ol class="breadcrumb">
        
           <li class="active">
               <p><br></p>
               <p><br></p>
              <i class="fa fa-dashboard">  Dashboard / Edit product</i>
           
           </li>
        </ol>
    
    </div>

</div>

<div class="row">

   <div class="col-lg-12">
   
       <div class="panel panel-default">
           <div class="panel-heading">
           
              <h3 class="panel-title"> <i class="fa fa-gear fa-fw"></i> Insert product
              </h3>
           
           </div>
           
           <div class="panel-body">
               <form class="form-horizontal" method="post" enctype="multipart/form-data">
               
                  <div class="form-group">
                      <label class="col-md-3 control-label">Product title</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="product_title" class="form-control" required value="<?php echo $p_title; ?>">
                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Brand</label>
                      
                      <div class="col-md-6">
                          <select name="brand" class="form-control">
                              <option value="<?php echo $brand_id; ?>"> <?php echo $brand_name; ?> </option>
                               <!-- connecting to database and calling product categories table -->
                              <?php
                              
                                $get_brand = "select * from brand";
                                 $run_brand = mysqli_query($con,$get_brand);
                                 
                                 while ($row_brands=mysqli_fetch_array($run_brand)){
                                    $brand_id = $row_brands['brand_id'];
                                    $brand_name = $row_brands['brand_name'];
                                    
                                    echo "
                                    <option value = '$brand_id'> $brand_name </option>
                                    
                                    ";
                                    
                                 
                                 }
                              
                              ?>
                          
                          </select>                      
                      </div>
                  
                  </div>
                   
                  
                  <div class="form-group">
                      <label class="col-md-3 control-label">Product Category</label>
                      
                      <div class="col-md-6">
                          <select name="product_cat" class="form-control">
                              <option value="<?php echo $p_cat; ?>"> <?php echo $p_cat_title; ?> </option>
                               <!-- connecting to database and calling product categories table -->
                              <?php
                              
                                $get_p_cats = "select * from product_categories";
                                 $run_p_cats = mysqli_query($con,$get_p_cats);
                                 
                                 while ($row_p_cats=mysqli_fetch_array($run_p_cats)){
                                    $p_cat_id = $row_p_cats['p_cat_id'];
                                    $p_cat_title = $row_p_cats['p_cat_title'];
                                    
                                    echo "
                                    <option value = '$p_cat_id'> $p_cat_title </option>
                                    
                                    ";
                                    
                                 
                                 }
                              
                              ?>
                          
                          </select>                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Category</label>
                      
                      <div class="col-md-6">
                          <select name="cat" class="form-control">
                              <option value="<?php echo $cat; ?>"> <?php echo $cat_title;?> </option>
                        <!-- connecting to database and calling categories table -->       
                              <?php
                              
                                $get_cat = "select * from categories";
                                 $run_cat = mysqli_query($con, $get_cat);
                                 
                                 while ($row_cat=mysqli_fetch_array($run_cat)){
                                    $cat_id = $row_cat['cat_id'];
                                    $cat_title = $row_cat['cat_title'];
                                    
                                    echo "
                                    <option value = '$cat_id'> $cat_title </option>
                                    
                                    ";
                                    
                                 
                                 }
                              
                              ?>
                          
                          </select>                      
                      </div>
                  
                  </div>
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Image 1</label>
                      
                      <div class="col-md-6">
                          <input type="file" name="product_img1" class="form-control" >
                      <br>
                          <img src="product_images/<?php echo $p_image1 ; ?>" alt="<?php echo $p_image1;?>" width="100" height="100">
                      </div>
                  
                  </div>
                  
<div class="form-group">
                      <label class="col-md-3 control-label">Product Image 2</label>
                      
                      <div class="col-md-6">
                          <input type="file" name="product_img2" class="form-control" >
                      <br>
                          <img src="product_images/<?php echo $p_image2 ; ?>" alt="<?php echo $p_image2;?>" width="100" height="100">
                      </div>
                  
                  </div>
                  
                   
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Image 3</label>
                      
                      <div class="col-md-6">
                          <input type="file" name="product_img3" class="form-control">
                      <br>
                          <img src="product_images/<?php echo $p_image3 ; ?>" alt="<?php echo $p_image3;?>" width="100" height="100">
                      </div>
                  
                  </div>
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Price</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="product_price" class="form-control" required value="<?php echo $p_price ; ?>">
                      
                      </div>
                  
                  </div>
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Keywords</label>
                      
                      <div class="col-md-6">
                          <input type="text" name="product_keywords" class="form-control" required value="<?php echo $p_keywords ; ?>">
                      
                      </div>
                  
                  </div>
                  
                   <div class="form-group">
                      <label class="col-md-3 control-label">Product Description</label>
                      
                      <div class="col-md-6">
                          
                  <textarea class="form-control" name="product_desc" cols="19" rows="6">
                          <?php echo $p_desc ; ?>
                          </textarea>
                      </div>
                  
                  </div>
                  
                    <div class="form-group">
                      <label class="col-md-3 control-label"></label>
                        
                      
                      <div class="col-md-6">
                         
                          <input class="btn btn-primary form-control" type="submit" name="update" value="Update Product">
                          
                          
                      </div>
                  
                  </div>
                  
               </form>
           
           </div>
       
       
       </div>
   
   </div>
</div>


 <script src="js/tinymce.5.4.1/content/scripts/tinymce.min.js"></script>
    <script src="js/tinymce.5.4.1/content/scripts/tinymce.js"></script>
     <script>tinymce.init({selector:'textarea'});</script>
    


</body>

</html>
<!-- method to make database actually store things when we insert -->
<!-- 'submit' is for the button name, $_POST is for <for method = "post"  -->
<?php

if(isset($_POST['update'])){ ///incase you updating everything--including pictures
    
    
    $product_title = $_POST['product_title'];
    $product_cat = $_POST['product_cat'];
    $cat = $_POST['cat'];                                           /* category */
    $brand = $_POST['brand'];
    $product_price = $_POST['product_price'];
    $product_keywords = $_POST['product_keywords'];
    $product_desc = $_POST['product_desc'];
    
    if(is_uploaded_file($_FILES['file']['tmp_name'])){
    
    $product_img1 = $_FILES['product_img1']['name'];
    $product_img2 = $_FILES['product_img2']['name'];
    $product_img3 = $_FILES['product_img3']['name'];
    
    $temp_name1 = $_FILES['product_img1']['tmp_name'];        /* temp name for images */
     $temp_name2 = $_FILES['product_img2']['tmp_name'];
     $temp_name3 = $_FILES['product_img3']['tmp_name'];
    
    
    /*sending image to the destination (place to be store) */
    
    move_uploaded_file($temp_name1, "product_images/$product_img1");
        move_uploaded_file($temp_name2, "product_images/$product_img2");
        move_uploaded_file($temp_name3, "product_images/$product_img3");
    
    /* query and command to update product */
  
    $update_product = "update products set p_cat_id='$product_cat',cat_id='$cat',brand_id='$brand',date=NOW(),product_title='$product_title', product_price='$product_price',product_img1='$product_img1',product_img2='$product_img2',product_img3='$product_img3',product_keywords='$product_keywords',product_desc='$product_desc' where product_id='$p_id'";
    
    $run_update = mysqli_query($con, $update_product);
    
    if ($run_update){
        echo "<script>alert('Product successfully updated')</script>";
    
        echo "<script>window.open('index.php?view_products','_self')</script>";
    }
    }
    else{
        ///If user did not update pictures.
          $update_product = "update products set p_cat_id='$product_cat',cat_id='$cat',brand_id='$brand',date=NOW(),product_title='$product_title', product_price='$product_price',product_keywords='$product_keywords',product_desc='$product_desc' where product_id='$p_id'";
    
    $run_update = mysqli_query($con, $update_product);
    
    if ($run_update){
        echo "<script>alert('Product successfully updated')</script>";
    
        echo "<script>window.open('index.php?view_products','_self')</script>";
    }
    }
}

?>

<?php } ?>