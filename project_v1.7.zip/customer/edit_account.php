<h2 align="center">Edit Account</h2>

<form action="" method="post" enctype="multipart/form-data">
     
     <div class="form-group">
     
     <label>
           Name:
     </label>
         <input type="text" name="c_name" class="form-control" required>
         
         
     </div>
     
          <div class="form-group">
     
     <label>
           E-mail:
     </label>
         <input type="text" name="c_email" class="form-control" required>
         
         
     </div>
     
          <div class="form-group">
     
     <label>
           Country:
     </label>
         <input type="text" name="c_country" class="form-control" required>
         
         
     </div>
          <div class="form-group">
     
     <label>
           City:
     </label>
         <input type="text" name="c_city" class="form-control" required>
         
         
     </div>
          <div class="form-group">
     
     <label>
           Cell number:
     </label>
         <input type="text" name="c_contact" class="form-control" required>
         
         
     </div>
     
          <div class="form-group">
     
     <label>
           Address:
     </label>
         <input type="text" name="c_address" class="form-control" required>
         
         
     </div>


 <div class="form-group">
     
     <label>
           Profile picture:
     </label>
         <input type="file" name="c_image" class="form-control" required>
         <img class="img-responsive" width="150px" height="150px" src="customer_images/avatar.jpg" alt="avatar">
         
     </div>
     
     <div class="text-center">
          <button name="update" class="btn btn-primary"><i class="fa fa-user-md">  Update picture</i></button>
     
     </div>




</form>