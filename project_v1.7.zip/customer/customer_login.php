<div class="box">

    <div class="box-header">
    
        <center>
        
            <h1>Login</h1>
            
            <p class="lead"> Got an account with us..?</p>
            <p class="text-muted">Sign in below</p>
        
        </center>
    
    </div>
    <!-- login form below -->
    
    <form action="checkout.php" method="post">
    
    
        <div class="form-group">
        
            <label>Email address</label>
            <input name="c_email" type="text" class="form-control" required>
        
        </div>
        
        <div class="form-group">
        
            <label>Password</label>
            <input name="c_password" type="password" class="form-control" required>
        
        </div>
        
        <div class="text-center">
        
            <button class="btn btn-primary" name="login" value="Login"> <i class="fa fa-sign-in">  Login</i></button>
        </div>
        
    </form> <!-- login form ends-->
    
    <center>
    
        <a href="../../TwoteStore/customer_register.php"><h3>Don't have account, click to register</h3></a>
    
    </center>

</div>

<?php

if(isset($_POST['login'])){
    
    $customer_email = $_POST['c_email'];
    
    $customer_pass = $_POST['c_password'];
    
    $select_customer = "select * from customers where customer_email='$customer_email' AND customer_pass='$customer_pass'";
    
    $run_customer = mysqli_query($con,$select_customer);
    
    $get_ip = getRealIpUser();
    
    $check_customer = mysqli_num_rows($run_customer);
    
    $select_cart = "select * from cart where ip_add='$get_ip'";
    
    $run_cart = mysqli_query($con,$select_cart);
    
    $check_cart = mysqli_num_rows($run_cart);
    
    if($check_customer==0){
        
        echo "<script> alert ('Email and password do not match')</script>";
            
        exit();
    }
    if ($check_customer==1 AND $check_cart==0){
        $_SESSION['customer_email'] = $customer_email;
        
        echo "<script> alert ('Logged in')</script>";
        
         echo "<script> window.open('customer/my_account.php?my_orders','_self')</script>";
        
    }
    else{
        $_SESSION['customer_email'] = $customer_email;
        
        echo "<script> alert ('Logged in')</script>";
        
         echo "<script> window.open('checkout.php','$_self')</script>";
        
    }
}

?>